



CREATE OR REPLACE VIEW rcm_app.xxrcm_cust_profile_gl_aud (rnum, rclm_cust_profile_id, gl, gl_id, active_flag, who_changed, changed_time, operation) AS select row_number() OVER () AS rnum, tab.RCLM_CUST_PROFILE_ID,tab.GL,tab.GL_ID,tab.ACTIVE_FLAG,tab.WHO_CHANGED,tab.CHANGED_TIME,tab.OPERATION FROM (select distinct a.rclm_cust_profile_id ,
		a.gl_id||' - '||a.gl_desc gl,
		        a.gl_id,
                a.active_flag,
                a.last_update_by who_changed,
                a.last_update_date changed_time,
		a.versions_operation operation
from rcm_app.xxrcm_cust_profile_gl versions between scn 0 and maxvalue a
where 1= 1 and versions_xid is not null
and 1=1
--and a.rclm_cust_profile_id = 2886540
--AND rclm_cust_profile_id = sys_context('RCMCTX', 'filter')
AND rclm_cust_profile_id = coalesce(sys_context('RCMCTX', 'filter'), rclm_cust_profile_id)
AND versions_operation <> 'U'
and last_update_date is not null
order by  last_update_date  desc, gl) tab;

CREATE OR REPLACE VIEW "RCM_APP"."XXRCM_CUST_PROFILE_GL" AS
SELECT * FROM "RCM_DATA"."XXRCM_CUST_PROFILE_GL";


*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_customer_master_ui_v (cs_store_num, rclm_customer_id, party_name, party_site_name, party_site_id, address, phone_number, city, state, postal_code, link_code, stat_format, party_id, account_number, account_name, account_ar_group_name, division_nbr, division_name, party_site_status, cust_store_num, chain_num, chain_name, grp_buy_nbr, customer_hq, party_site_creation_date, credit_hold, customer_group, party_site_number, email_address, zone_number, parent_store_num, rclm_customer_grp_num, rclm_customer_grp_name) AS select xcm.cs_store_num,
           xcm.rclm_customer_id,
           xcm.party_name,
           xcm.party_site_name,
           xcm.party_site_id,
           xcm.address,
           xcm.phone_number,
           xcm.city,
           xcm.state,
           xcm.postal_code,
           xcm.link_code,
           xcm.stat_format,
           xcm.party_id,
           xcm.account_number,
           xcm.account_name,
           xcm.account_ar_group_name,
           xcm.division_nbr,
           xcm.division_name,
           xcm.party_site_status,
           xcm.cust_store_num,
           xcm.chain_num,
           xcm.chain_name,
           xcm.grp_buy_nbr,
           xcm.customer_hq,
           xcm.party_site_creation_date,
           xcm.credit_hold,
           xcm.customer_group,
           xcm.party_site_number,
           xcm.email_address,
           xcm.zone_number,
           xcm.parent_store_num,
           xcg.rclm_customer_grp_num,
           xcg.rclm_customer_grp_name
      FROM rcm_data.xxrcm_customer_master xcm
LEFT OUTER JOIN rcm_data.xxrcm_customer_group xcg ON (xcm.rclm_customer_id = xcg.rclm_customer_id AND 'Active' = xcg.grp_store_status)
--WHERE   -- DEF#561
;


CREATE OR REPLACE VIEW rcm_app.xxrcm_cust_profile_scansrc_aud (rnum, rclm_cust_profile_id, scan_source_desc, active_flag, who_changed, changed_time, operation) AS select row_number() OVER () AS rnum, tab.RCLM_CUST_PROFILE_ID,tab.SCAN_SOURCE_DESC,tab.ACTIVE_FLAG,tab.WHO_CHANGED,tab.CHANGED_TIME,tab.OPERATION FROM (select distinct a.rclm_cust_profile_id ,
                a.scan_source_desc,
                a.active_flag,
                a.last_update_by who_changed,
                last_update_date changed_time,
		a.versions_operation operation
from rcm_app.xxrcm_cust_profile_scansrc versions between scn 0 and maxvalue a
where 1= 1 and versions_xid is not null
and 1=1
--and a.rclm_cust_profile_id = 2886540
--AND  rclm_cust_profile_id = sys_context('RCMCTX', 'filter')
AND (sys_context('RCMCTX', 'filter') IS NULL OR rclm_cust_profile_id = sys_context('RCMCTX', 'filter'))
AND versions_operation <> 'U'
and last_update_date is not null
order by  last_update_date  desc, a.scan_source_desc) tab;

CREATE OR REPLACE VIEW rcm_app.xxrcm_customer_profile_aud (rnum, rclm_cust_profile_id, field_name, new_val, old_val, versions_starttime, changed_time, who_changed) AS SELECT
          row_number() OVER () AS rnum,
          RCLM_CUST_PROFILE_ID,
          FIELD_NAME,
          REPLACE(NEW_VAL,'XX','') NEW_VAL,
          REPLACE(OLD_VAL,'XX','') OLD_VAL,
          versions_starttime,
          TO_DATE(TO_CHAR( changed_time,'DD-MON-YYYY HH24:MI:SS'),'DD-MON-YYYY HH24:MI:SS') changed_time ,
          who_changed --, changed_time1
     FROM
          (SELECT * FROM (SELECT RCLM_CUST_PROFILE_ID,
            'Profile Status' FIELD_NAME,
          coalesce(PROFILE_STATUS ,'XX') NEW_VAL ,
          coalesce(LEAD(PROFILE_STATUS) OVER (PARTITION BY RCLM_CUST_PROFILE_ID ORDER BY last_update_date DESC),'XX') AS OLD_VAL ,
            last_update_date versions_starttime ,
            last_update_date changed_time,
            last_update_by who_changed
          FROM RCM_DATA.XXRCM_CUSTOMER_PROFILE VERSIONS
          BETWEEN SCN 0 and MAXVALUE
          WHERE 1           = 1
          AND versions_xid IS NOT NULL
	  AND RCLM_CUST_PROFILE_ID = sys_context('RCMCTX', 'filter')
	  ) alias9 
          WHERE NEW_VAL <> OLD_VAL     -- /* AND versions_operation  = 'U' */
)
    
UNION ALL

          SELECT * FROM (SELECT RCLM_CUST_PROFILE_ID,
          'Allow Customer Owned Items' FIELD_NAME,
          coalesce(ALLOW_CUST_OWNED_ITEMS ,'XX') NEW_VAL ,
          coalesce(LEAD(ALLOW_CUST_OWNED_ITEMS) OVER (PARTITION BY RCLM_CUST_PROFILE_ID ORDER BY last_update_date DESC),'XX') AS OLD_VAL ,
          last_update_date versions_starttime ,
          last_update_date changed_time,
          last_update_by who_changed
          FROM RCM_DATA.XXRCM_CUSTOMER_PROFILE VERSIONS
          BETWEEN SCN 0 and MAXVALUE
          WHERE 1           =1
          AND versions_xid IS NOT NULL
	  AND RCLM_CUST_PROFILE_ID = sys_context('RCMCTX', 'filter')
          /* AND versions_operation  = 'U' */
 ) alias15  WHERE NEW_VAL <> OLD_VAL
    
UNION ALL

          SELECT * FROM (SELECT RCLM_CUST_PROFILE_ID,
            'Scan Against Sales' FIELD_NAME,
            coalesce(SCAN_AGAINST_SALES_FLAG ,'XX') NEW_VAL ,
            coalesce(LEAD(SCAN_AGAINST_SALES_FLAG) OVER (PARTITION BY RCLM_CUST_PROFILE_ID ORDER BY last_update_date DESC),'XX') AS OLD_VAL ,
            last_update_date versions_starttime ,
            last_update_date changed_time,
            ( last_update_by
            ) who_changed
          FROM RCM_DATA.XXRCM_CUSTOMER_PROFILE VERSIONS
          BETWEEN SCN 0 and MAXVALUE
          WHERE 1           =1
          AND versions_xid IS NOT NULL
	  AND RCLM_CUST_PROFILE_ID = sys_context('RCMCTX', 'filter')
             /* AND versions_operation  = 'U' */
 ) alias22  WHERE NEW_VAL <> OLD_VAL
   
UNION ALL

    SELECT * FROM (SELECT RCLM_CUST_PROFILE_ID,
      'W Avg Horizon Validation' FIELD_NAME,
      coalesce(WGHT_AVG_TIME_HORIZ_VALIDA_WKS::varchar ,'XX') NEW_VAL ,
      coalesce((LEAD(WGHT_AVG_TIME_HORIZ_VALIDA_WKS) OVER (PARTITION BY RCLM_CUST_PROFILE_ID ORDER BY last_update_date DESC))::varchar,'XX') AS OLD_VAL ,
      last_update_date versions_starttime ,
      last_update_date changed_time,
      last_update_by who_changed
    FROM RCM_DATA.XXRCM_CUSTOMER_PROFILE VERSIONS
    BETWEEN SCN 0 and MAXVALUE
    WHERE 1           =1
    AND versions_xid IS NOT NULL
    AND RCLM_CUST_PROFILE_ID = sys_context('RCMCTX', 'filter')
       /* AND versions_operation  = 'U' */
 ) alias29  WHERE NEW_VAL <> OLD_VAL
    
UNION ALL

    SELECT * FROM (SELECT RCLM_CUST_PROFILE_ID,
      'Scan Authorization' FIELD_NAME,
      coalesce(AUTHORIZED_SCAN ,'XX') NEW_VAL ,
     coalesce(LEAD(AUTHORIZED_SCAN) OVER (PARTITION BY RCLM_CUST_PROFILE_ID ORDER BY last_update_date DESC),'XX') AS OLD_VAL ,
      last_update_date versions_starttime ,
      last_update_date changed_time,
      last_update_by who_changed
    FROM RCM_DATA.XXRCM_CUSTOMER_PROFILE VERSIONS
    BETWEEN SCN 0 and MAXVALUE
    WHERE 1           =1
    AND versions_xid IS NOT NULL
    AND RCLM_CUST_PROFILE_ID = sys_context('RCMCTX', 'filter')
       /* AND versions_operation  = 'U' */
 ) alias35  WHERE NEW_VAL <> OLD_VAL
 
UNION ALL

    SELECT * FROM (SELECT RCLM_CUST_PROFILE_ID,
      'Pvt Label Authorization' FIELD_NAME,
      coalesce(AUTHORIZED_PL ,'XX') NEW_VAL ,
      coalesce(LEAD(AUTHORIZED_PL) OVER (PARTITION BY RCLM_CUST_PROFILE_ID ORDER BY last_update_date DESC),'XX') AS OLD_VAL ,
      last_update_date versions_starttime ,
      last_update_date changed_time,
      last_update_by who_changed
    FROM RCM_DATA.XXRCM_CUSTOMER_PROFILE VERSIONS
    BETWEEN SCN 0 and MAXVALUE
    WHERE 1           =1
    AND versions_xid IS NOT NULL
    AND RCLM_CUST_PROFILE_ID = sys_context('RCMCTX', 'filter')
       /* AND versions_operation  = 'U' */
 ) alias41  WHERE NEW_VAL <> OLD_VAL
 
UNION ALL

    SELECT * FROM (SELECT RCLM_CUST_PROFILE_ID,
      'Comments' FIELD_NAME,
      coalesce(REASON_CODE ,'XX') NEW_VAL ,
      coalesce(LEAD(REASON_CODE) OVER (PARTITION BY RCLM_CUST_PROFILE_ID ORDER BY last_update_date DESC),'XX') AS OLD_VAL ,
      last_update_date versions_starttime ,
      last_update_date changed_time,
      last_update_by who_changed
    FROM RCM_DATA.XXRCM_CUSTOMER_PROFILE VERSIONS
    BETWEEN SCN 0 and MAXVALUE
    WHERE 1           =1
    AND versions_xid IS NOT NULL
    AND RCLM_CUST_PROFILE_ID = sys_context('RCMCTX', 'filter')
       /* AND versions_operation  = 'U' */
 ) alias47  WHERE NEW_VAL <> OLD_VAL
 
UNION ALL

    SELECT * FROM (SELECT RCLM_CUST_PROFILE_ID,
      'Credit % Cost' FIELD_NAME,
      coalesce(CREDIT_PCT_COST::varchar ,'XX') NEW_VAL ,
      coalesce((LEAD(CREDIT_PCT_COST) OVER (PARTITION BY RCLM_CUST_PROFILE_ID ORDER BY last_update_date DESC))::varchar,'XX') AS OLD_VAL ,
      last_update_date versions_starttime ,
      last_update_date changed_time,
      last_update_by who_changed
    FROM RCM_DATA.XXRCM_CUSTOMER_PROFILE VERSIONS
    BETWEEN SCN 0 and MAXVALUE
    WHERE 1           =1
    AND versions_xid IS NOT NULL
    AND RCLM_CUST_PROFILE_ID = sys_context('RCMCTX', 'filter')
       /*  AND versions_operation  = 'U' */
  ) alias54  WHERE NEW_VAL <> OLD_VAL
      ) alias55
WHERE coalesce(NEW_VAL,'ZXY') <> coalesce(OLD_VAL,'!ZXY')
AND ( sys_context('RCMCTX', 'filter') is null
      AND  1=1
      OR RCLM_CUST_PROFILE_ID = sys_context('RCMCTX', 'filter')
     )
and versions_starttime is not null
--AND RCLM_CUST_PROFILE_ID = sys_context('RCMCTX', 'filter')
 
  ORDER BY versions_starttime DESC;


******DONE******
CREATE OR REPLACE VIEW rcm_app.xxrcm_file_tracker_vw (job_id, file_id, file_name, file_path, sql_query, requested_by, request_type, file_data, file_type, batch_id, search_params, template_yn, rows_to_skip, validation_status, error_message, file_moved_status, success_count, error_count, total_count, error_file_data, error_file_id, error_file_available, created_by, creation_date, last_updated_by, last_update_date, trunc_creation_date) AS ( SELECT job_id
        ,file_id
        ,file_name
        ,file_path
        ,sql_query
        ,requested_by
		,request_type
        ,file_data
        ,file_type
		,batch_id
        ,search_params
		,template_yn
        ,rows_to_skip
        ,validation_status
        ,error_message
        ,file_moved_status
        ,success_count
        ,error_count
        ,total_count
        ,error_file_data
		,error_file_id
        ,error_file_available
        ,created_by
        ,creation_date
        ,last_updated_by
        ,last_update_date
        ,date_trunc('day', creation_date) trunc_creation_date
  FROM rcm_data.xxrcm_file_tracker
  );

CREATE OR REPLACE VIEW rcm_app.xxrcm_client_group_cust_lkp (map_definition_id, map_code, map_desc, sequence_id, c_value1_prompt_text, system, c_value2_prompt_text, customer_group, c_value3_prompt_text, data_feed, c_value4_prompt_text) AS (SELECT def.map_definition_id
         , def.map_code
         , def.map_desc
         , val.c_value1 sequence_id
         , def.c_value1_prompt_text
         , val.c_value2 system
         , def.c_value2_prompt_text
         , val.c_value3 customer_group
         , def.c_value3_prompt_text
         , val.c_value4 data_feed
         , def.c_value4_prompt_text
      FROM rcm_cmn.xxrcm_value_map_def def, rcm_cmn.xxrcm_value_map val
     WHERE def.map_code = 'XXRCM_CUSTOMER_OUTBOUND'
       AND def.map_definition_id = val.map_definition_id);

CREATE OR REPLACE VIEW rcm_app.xxrcm_cust_mas_chn_hq_map_v (map_definition_id, map_code, map_desc, chain_num, n_value1_sequence, n_value1_required_flag, n_value1_column_width, customer_hq, n_value2_sequence, n_value2_required_flag, n_value2_column_width, active_date_flag, active_begin_date, active_end_date) AS select def.map_definition_id,
       def.map_code,
       def.map_desc,
       val.n_value1  CHAIN_NUM,
       def.n_value1_sequence,
       def.n_value1_required_flag,
       def.n_value1_column_width,
       val.n_value2  CUSTOMER_HQ,
       def.n_value2_sequence,
       def.n_value2_required_flag,
       def.n_value2_column_width,
       def.active_date_flag,
       def.active_begin_date,
       def.active_end_date
FROM rcm_cmn.xxrcm_value_map_def def,
      rcm_cmn.xxrcm_value_map val
where def.map_code = 'XXRCM_CUST_HQ_NUM_MAPPING'
and def.map_definition_id = val.map_definition_id
and def.active_begin_date < date_trunc('day', statement_timestamp())
and (def.active_end_date > statement_timestamp() or def.active_end_date is null);

CREATE OR REPLACE VIEW rcm_app.xxrcm_cust_mas_chn_grp_map_v (map_definition_id, map_code, map_desc, chain_num, n_value1_sequence, n_value1_required_flag, n_value1_column_width, rclm_grp_name, c_value1_prompt_text, c_value1_sequence, c_value1_required_flag, c_value1_column_width, cs_store_num, c_value5_sequence, c_value5_required_flag, c_value5_column_width, use_icost_at_no_sales, c_value2_prompt_text, c_value2_sequence, c_value2_required_flag, c_value2_column_width, division_nbr, n_value3_sequence, n_value3_required_flag, n_value3_column_width, account_ar_group_name, c_value3_prompt_text, c_value3_sequence, c_value3_required_flag, c_value3_column_width, rclm_grp_num, n_value4_sequence, n_value4_required_flag, n_value4_column_width, rclm_grp_short_name, c_value4_prompt_text, c_value4_sequence, c_value4_required_flag, c_value4_column_width, active_date_flag, active_begin_date, active_end_date) AS select def.map_definition_id,
       def.map_code,
       def.map_desc,
       val.n_value1  CHAIN_NUM,
       def.n_value1_sequence,
       def.n_value1_required_flag,
       def.n_value1_column_width,
       val.c_value1 RCLM_GRP_NAME,
       def.c_value1_prompt_text,
       def.c_value1_sequence,
       def.c_value1_required_flag,
       def.c_value1_column_width,
	   val.c_value5  CS_STORE_NUM,
       def.c_value5_sequence,
       def.c_value5_required_flag,
       def.c_value5_column_width,
	   val.c_value2 USE_ICOST_AT_NO_SALES,
       def.c_value2_prompt_text,
       def.c_value2_sequence,
       def.c_value2_required_flag,
       def.c_value2_column_width,
	   val.n_value3  DIVISION_NBR,
       def.n_value3_sequence,
       def.n_value3_required_flag,
       def.n_value3_column_width,
	   val.c_value3 ACCOUNT_AR_GROUP_NAME,
       def.c_value3_prompt_text,
       def.c_value3_sequence,
       def.c_value3_required_flag,
       def.c_value3_column_width,
	   val.n_value4  RCLM_GRP_NUM,
       def.n_value4_sequence,
       def.n_value4_required_flag,
       def.n_value4_column_width,
	   val.c_value4 RCLM_GRP_SHORT_NAME,
       def.c_value4_prompt_text,
       def.c_value4_sequence,
       def.c_value4_required_flag,
       def.c_value4_column_width,
	   def.active_date_flag,
       def.active_begin_date,
       def.active_end_date
FROM rcm_cmn.xxrcm_value_map_def def,
      rcm_cmn.xxrcm_value_map val
where def.map_code = 'XXRCM_CUST_RCLM_GRP_MAPPING'
and def.map_definition_id = val.map_definition_id
and def.active_begin_date < date_trunc('day', statement_timestamp())
and (def.active_end_date > statement_timestamp() or def.active_end_date is null);


*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_file_controller_vw (job_id, control_name, control_type, file_name, file_path, file_type, file_schema, no_of_columns, db_type, insert_type, db_table_type_name, sql_query, insert_procedure, insert_proc_params, processing_procedure, processing_proc_params, lov_columns, web_url, connection_timeout, read_timeout, webservice_params, default_rows_for_lov, generate_file, error_file_yn, active, archival_sucess_path, archival_failure_path, rows_to_skip, is_partial_load_enabled, batch_size, create_ticket, send_email, email_list, window_size_for_sxssf, validation_columns, error_file_control_name, created_by, creation_date, last_updated_by, last_update_date) AS ( SELECT job_id
        ,control_name
        ,control_type
	    ,file_name
        ,file_path
        ,file_type
        ,file_schema
        ,no_of_columns
        ,db_type
        ,insert_type
        ,db_table_type_name
        ,sql_query
        ,insert_procedure
        ,insert_proc_params
        ,processing_procedure
        ,processing_proc_params
        ,lov_columns
		,web_url
	    ,connection_timeout
	    ,read_timeout
	    ,webservice_params
	    ,default_rows_for_lov
	    ,generate_file
        ,error_file_yn
        ,active
        ,archival_sucess_path
        ,archival_failure_path
        ,rows_to_skip
        ,is_partial_load_enabled
        ,batch_size
        -- Added on 10/05/2018
		,create_ticket
        ,send_email
        ,email_list
		,window_size_for_sxssf
		,validation_columns
        -- Ended on 10/05/2018
        ,error_file_control_name  -- Added on 09/26/2018
        ,created_by
        ,creation_date
        ,last_updated_by
        ,last_update_date
   FROM rcm_data.xxrcm_file_controller
);


*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_file_status_vw (job_id, control_name, control_type, file_id, file_path, file_name, file_type, db_table_type_name, file_schema, web_url, requested_by, request_type, batch_id, search_params, template_yn, file_data, validation_status, error_message, file_moved_status, success_count, error_count, total_count, error_file_data, error_file_id, error_file_available, error_file_yn, rows_to_skip, error_file_control_name, created_by, creation_date, last_updated_by, last_update_date, trunc_creation_date) AS ( SELECT xft.job_id
        ,xfc.control_name
        ,xfc.control_type
		,xft.file_id
		,coalesce( xft.file_path, xfc.file_path ) file_path
        ,coalesce( xft.file_name, xfc.file_name ) file_name
		,coalesce( xft.file_type, xfc.file_type ) file_type
        ,xfc.db_table_type_name
		,xfc.file_schema
		,xfc.web_url
		,xft.requested_by
		,xft.request_type
		,xft.batch_id
        ,xft.search_params
		,xft.template_yn
		,xft.file_data
		,xft.validation_status
        ,xft.error_message
        ,xft.file_moved_status
        ,xft.success_count
        ,xft.error_count
        ,xft.total_count
		,xft.error_file_data
		,xft.error_file_id
        ,coalesce( xft.error_file_available, 'N' ) error_file_available
		,coalesce( xfc.error_file_yn, 'N' ) error_file_yn
		,xft.rows_to_skip
		,xfc.error_file_control_name  -- Added on 09/26/2018
        ,xft.created_by
        ,xft.creation_date
        ,xft.last_updated_by
        ,xft.last_update_date
        ,date_trunc('day', xft.creation_date) trunc_creation_date
  FROM rcm_app.xxrcm_file_controller_vw xfc
      ,rcm_app.xxrcm_file_tracker_vw xft
 WHERE xfc.job_id = xft.job_id
 );


*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_vendor_master_vw (reclaim_vendor_id, vendor_id, ap_vendor_number, ap_vendor_name, vendor_type, client, vendor_type_def, address, address1, address2, address3, city, state, zip_code, inactive_date, vendor_contact_name, vendor_contact_name_ui, vendor_email, vendor_email_ui, swell_flag, comments, auth_for_debt, apply_max_vend_cost, auth_reason, reclaim_inactive_date, reclaim_last_scan, reclaim_volume_per_week, reclaim_dollars_per_week, reclaim_on_hold, rule_process_status, created_by, creation_date, last_updated_by, last_update_date) AS ( SELECT xvm.reclaim_vendor_id
        ,xvm.vendor_id
	    ,xvm.ap_vendor_number
	    ,xvm.ap_vendor_name
	    ,xvm.vendor_type
	    ,xvm.client
	    ,CASE WHEN xvm.vendor_type = 'I' THEN
	              'C&S Vendor'
		      ELSE 'Customer Vendor'
	       END vendor_type_def
		,xvm.address
		,xvm.address1
		,xvm.address2
		,xvm.address3
		,xvm.city
		,xvm.state
		,xvm.zip_code
		,xvm.inactive_date
		,xvm.vendor_contact_name
		,xvm.vendor_contact_name_ui
		,xvm.vendor_email
		,xvm.vendor_email_ui
		,xvm.swell_flag
		,xvm.comments
		,xvm.auth_for_debt
		,xvm.apply_max_vend_cost
		,xvm.auth_reason
		,xvm.reclaim_inactive_date
		,xvm.reclaim_last_scan
		,xvm.reclaim_volume_per_week
		,xvm.reclaim_dollars_per_week
		,xvm.reclaim_on_hold
		,xvm.rule_process_status  -- Added on 10/11/2018
		,xvm.created_by
		,xvm.creation_date
		,xvm.last_updated_by
		,xvm.last_update_date
    FROM rcm_data.XXRCM_VENDOR_MASTER xvm
);


*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_vendor_prof_fee_summ_stg (file_name, created_by, creation_date, last_updated_by, last_update_date, request_id, batch_id, record_source, total_rows, success_rows, error_rows, process_status) AS ( SELECT DISTINCT file_name
        ,created_by
        ,creation_date
        ,last_updated_by
        ,last_update_date
        ,request_id
        ,batch_id
		,'FILE' record_source
        ,COUNT(1) OVER ( PARTITION BY batch_id ) total_rows
		,SUM( CASE WHEN process_status = 'S' THEN 1 ELSE 0 END ) OVER ( PARTITION BY batch_id ) success_rows
		,SUM( CASE WHEN process_status = 'E' THEN 1 ELSE 0 END ) OVER ( PARTITION BY batch_id ) error_rows
		,CASE WHEN SUM( CASE WHEN process_status = 'E' THEN 1 ELSE 0 END ) OVER ( PARTITION BY batch_id ) > 0 THEN
		            'Error'
			   ELSE 'Success'
		   END process_status
   FROM rcm_data.XXRCM_VENDOR_PROF_FEE_STG
);

CREATE OR REPLACE VIEW rcm_app.xxrcm_gl_list (map_definition_id, map_code, map_desc, gl_number, c_value1_prompt_text, gl_desc, c_value2_prompt_text, active_date_flag, active_begin_date, active_end_date) AS (
select def.map_definition_id,
       def.map_code,
       def.map_desc,
      val.c_value1 GL_NUMBER,
       def.c_value1_prompt_text,
	   val.c_value2 GL_DESC,
       def.c_value2_prompt_text,
	     def.active_date_flag,
       def.active_begin_date,
       def.active_end_date
FROM rcm_cmn.xxrcm_value_map_def def,
      rcm_cmn.xxrcm_value_map val
where def.map_code = 'XXRCM_GL_LIST'
and def.map_definition_id = val.map_definition_id
and statement_timestamp() between def.active_begin_date  and coalesce(def.active_end_date ,statement_timestamp() + interval '1 days') );


CREATE OR REPLACE VIEW rcm_app.xxrcm_item_master AS
SELECT * FROM rcm_data.xxrcm_item_master;


*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_core_processing_rule_v (ap_vendor_name, ap_vendor_number, binary_rule_level_identifier, chain_name, chain_number, comments, created_by, creation_date, credit_authorized, credit_percent, customer_auth_pvt_label, cust_item_code, debit_authorized, disposition, division, facility_code, facility_name, gl_code, hazd_flag, item_reclaimable_flag, item_upc, last_updated_by, last_update_date, master_item_id, new_reclaim_vendor_id, new_vendor, new_vendor_name, org_id, pack, private_label, rank, rclm_customer_grp_id, rclm_customer_grp_name, rclm_customer_grp_num, recall_class, recall_flag, reclaim_as_service, reclaim_vendor_id, request_id, rule_effective_from, rule_effective_to, rule_entered_purch_cost, rule_id, rule_process_status, rule_updateable, rule_weighted_avg_sales_cost, seq_id, ssic, store, store_name, sub_classification, swell, vndr_deduct_reason, deduct_reason_desc, warehouse_damage_rule, whse_item_code, whse_item_id, gl_desc, master_upc, upc, item_description_case, has_vendor_fee, has_customer_fee) AS select rules.AP_VENDOR_NAME ,
               rules.AP_VENDOR_NUMBER                    ,
               rules.BINARY_RULE_LEVEL_IDENTIFIER        ,
               rules.CHAIN_NAME                          ,
               rules.CHAIN_NUMBER                        ,
               rules.COMMENTS                            ,
               rules.CREATED_BY                          ,
               rules.CREATION_DATE                       ,
               rules.CREDIT_AUTHORIZED                   ,
               rules.CREDIT_PERCENT                      ,
               rules.CUSTOMER_AUTH_PVT_LABEL             ,
               rules.CUST_ITEM_CODE                      ,
               rules.DEBIT_AUTHORIZED                    ,
               rules.DISPOSITION                         ,
               rules.DIVISION                            ,
               rules.FACILITY_CODE                       ,
               rules.FACILITY_NAME                       ,
               rules.GL_CODE                             ,
               rules.HAZD_FLAG                           ,
               rules.ITEM_RECLAIMABLE_FLAG               ,
               rules.ITEM_UPC                            ,
               rules.LAST_UPDATED_BY                     ,
               rules.LAST_UPDATE_DATE                    ,
               rules.MASTER_ITEM_ID                      ,
               rules.NEW_RECLAIM_VENDOR_ID               ,
               rules.NEW_VENDOR                          ,
               rules.NEW_VENDOR_NAME                     ,
               rules.ORG_ID                              ,
               rules.PACK                                ,
               rules.PRIVATE_LABEL                       ,
               rules.RANK                                ,
               rules.RCLM_CUSTOMER_GRP_ID                ,
               rules.RCLM_CUSTOMER_GRP_NAME              ,
               rules.RCLM_CUSTOMER_GRP_NUM               ,
               rules.RECALL_CLASS                        ,
               rules.RECALL_FLAG                         ,
               rules.RECLAIM_AS_SERVICE                  ,
               rules.RECLAIM_VENDOR_ID                   ,
               rules.REQUEST_ID                          ,
               rules.RULE_EFFECTIVE_FROM                 ,
               rules.RULE_EFFECTIVE_TO                   ,
               rules.RULE_ENTERED_PURCH_COST             ,
               rules.RULE_ID                             ,
               rules.RULE_PROCESS_STATUS                 ,
               rules.RULE_UPDATEABLE                     ,
               rules.RULE_WEIGHTED_AVG_SALES_COST        ,
               rules.SEQ_ID                              ,
               rules.SSIC                                ,
               rules.STORE                               ,
               rules.STORE_NAME                          ,
               rules.SUB_CLASSIFICATION                  ,
               rules.SWELL                               ,
               rules.VNDR_DEDUCT_REASON             ,
			   (select drc.debit_reason_descr
	              FROM rcm_app.xxrcm_debit_reason_codes_v drc
	             where drc.debit_reason= rules.vndr_deduct_reason
	           ) DEDUCT_REASON_DESC,
               rules.WAREHOUSE_DAMAGE_RULE               ,
               rules.WHSE_ITEM_CODE                      ,
               rules.WHSE_ITEM_ID                        ,
               gls.gl_desc,	              -- gl desc
               itm.master_upc,            -- master upc
               itm.upc, --
               itm.item_description_case, -- master upc desc
        	   coalesce((select 'Y' from rcm_data.xxrcm_fee_details
        	    where profile_id = rules.rule_id
        		  and upper(fee_type)   = 'VENDOR'
				  and status     = 'Active'
				  --and sysdate between start_date and nvl(end_date,sysdate+1)),'N') HAS_VENDOR_FEE,
				  and coalesce(end_date,date_trunc('day', statement_timestamp()))>= date_trunc('day', statement_timestamp())  LIMIT 1 OFFSET -1),'N') HAS_VENDOR_FEE,
        	   coalesce((select 'Y' from rcm_data.xxrcm_fee_details
        	    where profile_id = rules.rule_id
        		  and upper(fee_type)   = 'CUSTOMER' 
				  and status     = 'Active'
				  -- and sysdate between start_date and nvl(end_date,sysdate+1)),'N') HAS_CUSTOMER_FEE
				  and coalesce(end_date,date_trunc('day', statement_timestamp()))>=date_trunc('day', statement_timestamp())  LIMIT 1 OFFSET -1),'N') HAS_CUSTOMER_FEE
        FROM rcm_app.xxrcm_core_processing_rule rules
LEFT OUTER JOIN rcm_app.xxrcm_gl_list gls ON (rules.gl_code = gls.gl_number)
LEFT OUTER JOIN rcm_app.xxrcm_item_master itm ON (rules.item_upc = itm.upc_item);


*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_core_proces_rule_exp_v (ap_vendor_id, ap_vendor_name, ap_vendor_number, ap_vend_inactive_date, batch_id, binary_rule_level_identifier, bottle_deposit, chain_name, chain_number, comments, created_by, creation_date, credit_authorized, credit_percent, crosscode_cs_item, customer_auth_pvt_label, customer_cost, customer_dept, customer_hq, customer_id, customer_item_code, customer_item_id, customer_name, customer_profile_id, customer_state, customer_state_code, cust_itmrec_id, cust_profile_status, cust_reclaim_item_status, cust_store_num, debit_authorized, disposition, division_name, division_nbr, error_message, explosion_source, facility, facility_name, fee_grp_id, gl_code, grp_store_status, has_customer_fee, has_vendor_fee, hazd_flag, icost, item_inv_status, item_purchase_status, item_reclaimable_flag, item_type, item_upc, last_update_by, last_update_date, master_item_id, master_rec_purchase_cost, master_rec_wt_avg_sales_cost, military_unique, pack, pack_in_carton, party_site_status, piece_in_pack, private_label, purchase_cost, rclm_customer_grp_id, rclm_customer_grp_name, rclm_customer_grp_num, rcost, recall_class, recall_flag, reclaim_as_service, reclaim_item, reclaim_item_status, reclaim_vendor_id, reclaim_vendor_name, reclaim_vendor_num, reclaim_vend_inactive_date, request_id, rule_effective_from, rule_effective_to, rule_exp_id, rule_profile_id, sales_history_exists, scan_authorized, source, status, store, sub_classification, swell, tobacco_credit_method, tobacco_state_tax, tobacco_type, unit_factor, upc_description_case, use_icost_at_no_sales, vendor_profile_id, weighted_avg_sales_cost, whse_code, whse_item_code, whse_item_id, gl_desc) AS select rules.AP_VENDOR_ID                 ,
             rules.AP_VENDOR_NAME                 ,
             rules.AP_VENDOR_NUMBER               ,
             rules.AP_VEND_INACTIVE_DATE          ,
             rules.BATCH_ID                       ,
             rules.BINARY_RULE_LEVEL_IDENTIFIER   ,
             rules.BOTTLE_DEPOSIT                 ,
             rules.CHAIN_NAME                     ,
             rules.CHAIN_NUMBER                   ,
             rules.COMMENTS                       ,
             rules.CREATED_BY                     ,
             rules.CREATION_DATE                  ,
             rules.CREDIT_AUTHORIZED              ,
             rules.CREDIT_PERCENT                 ,
             rules.CROSSCODE_CS_ITEM              ,
             rules.CUSTOMER_AUTH_PVT_LABEL        ,
             rules.CUSTOMER_COST                  ,
             rules.CUSTOMER_DEPT                  ,
             rules.CUSTOMER_HQ                    ,
             rules.CUSTOMER_ID                    ,
             rules.CUSTOMER_ITEM_CODE             ,
             rules.CUSTOMER_ITEM_ID               ,
             rules.CUSTOMER_NAME                  ,
             rules.CUSTOMER_PROFILE_ID            ,
             rules.CUSTOMER_STATE                 ,
             rules.CUSTOMER_STATE_CODE            ,
             rules.CUST_ITMREC_ID                 ,
             rules.CUST_PROFILE_STATUS            ,
             rules.CUST_RECLAIM_ITEM_STATUS       ,
             rules.CUST_STORE_NUM                 ,
             rules.DEBIT_AUTHORIZED               ,
             rules.DISPOSITION                    ,
             rules.DIVISION_NAME                  ,
             rules.DIVISION_NBR                   ,
             rules.ERROR_MESSAGE                  ,
             rules.EXPLOSION_SOURCE               ,
             rules.FACILITY                       ,
             rules.FACILITY_NAME                  ,
             rules.FEE_GRP_ID                     ,
             rules.GL_CODE                        ,
             rules.GRP_STORE_STATUS               ,
             rules.HAS_CUSTOMER_FEE               ,
             rules.HAS_VENDOR_FEE                 ,
             rules.HAZD_FLAG                      ,
             rules.ICOST                          ,
             rules.ITEM_INV_STATUS                ,
             rules.ITEM_PURCHASE_STATUS           ,
             rules.ITEM_RECLAIMABLE_FLAG          ,
             rules.ITEM_TYPE                      ,
             rules.ITEM_UPC                       ,
             rules.LAST_UPDATE_BY                 ,
             rules.LAST_UPDATE_DATE               ,
             rules.MASTER_ITEM_ID                 ,
             rules.MASTER_REC_PURCHASE_COST       ,
             rules.MASTER_REC_WT_AVG_SALES_COST   ,
             rules.MILITARY_UNIQUE                ,
             rules.PACK                           ,
             rules.PACK_IN_CARTON                 ,
             rules.PARTY_SITE_STATUS              ,
             rules.PIECE_IN_PACK                  ,
             rules.PRIVATE_LABEL                  ,
             rules.PURCHASE_COST                  ,
             rules.RCLM_CUSTOMER_GRP_ID           ,
             rules.RCLM_CUSTOMER_GRP_NAME         ,
             rules.RCLM_CUSTOMER_GRP_NUM          ,
             rules.RCOST                          ,
             rules.RECALL_CLASS                   ,
             rules.RECALL_FLAG                    ,
             rules.RECLAIM_AS_SERVICE             ,
             rules.RECLAIM_ITEM                   ,
             rules.RECLAIM_ITEM_STATUS            ,
             rules.RECLAIM_VENDOR_ID              ,
             rules.RECLAIM_VENDOR_NAME            ,
             rules.RECLAIM_VENDOR_NUM             ,
             rules.RECLAIM_VEND_INACTIVE_DATE     ,
             rules.REQUEST_ID                     ,
             rules.RULE_EFFECTIVE_FROM            ,
             rules.RULE_EFFECTIVE_TO              ,
             rules.RULE_EXP_ID                    ,
             rules.RULE_PROFILE_ID                ,
             rules.SALES_HISTORY_EXISTS           ,
             rules.SCAN_AUTHORIZED                ,
             rules.SOURCE                         ,
             rules.STATUS                         ,
             rules.STORE                          ,
             rules.SUB_CLASSIFICATION             ,
             rules.SWELL                          ,
             rules.TOBACCO_CREDIT_METHOD          ,
             rules.TOBACCO_STATE_TAX              ,
             rules.TOBACCO_TYPE                   ,
             rules.UNIT_FACTOR                    ,
             rules.UPC_DESCRIPTION_CASE           ,
             rules.USE_ICOST_AT_NO_SALES          ,
             rules.VENDOR_PROFILE_ID              ,
            /* rules.VNDR_DEDUCT_REASON             ,
			 (select drc.debit_reason_descr
	          from rcm_app.xxrcm_debit_reason_codes_v drc
	          where drc.debit_reason= rules.vndr_deduct_reason
	        ) debit_reason_desc, */
             rules.WEIGHTED_AVG_SALES_COST        ,
             rules.WHSE_CODE                      ,
             rules.WHSE_ITEM_CODE                 ,
             rules.WHSE_ITEM_ID                   ,
             gls.gl_desc
         FROM rcm_app.xxrcm_core_proces_rule_exp rules
LEFT OUTER JOIN rcm_app.xxrcm_gl_list gls ON (rules.gl_code::varchar = gls.gl_number);


CREATE OR REPLACE VIEW rcm_app.xxrcm_value_map_def AS 
SELECT * 
FROM rcm_cmn.xxrcm_value_map_def;

CREATE OR REPLACE VIEW rcm_app.xxrcm_value_map AS 
SELECT * 
FROM rcm_cmn.xxrcm_value_map;


*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_debit_reason_codes_v (map_definition_id, map_code, map_desc, debit_reason, debit_reason_descr, active_date_flag, active_begin_date, active_end_date) AS select
       def.map_definition_id,
       def.map_code,
       def.map_desc,
       val.c_value1 debit_reason,
       val.c_value2 debit_reason_descr,
       def.active_date_flag,
       def.active_begin_date,
       def.active_end_date
FROM  rcm_app.xxrcm_value_map_def def,
      rcm_app.xxrcm_value_map val
where def.map_code = 'XXRCM_DEBIT_REASON_CODES'
and def.map_definition_id = val.map_definition_id
and statement_timestamp() between def.active_begin_date  and coalesce(def.active_end_date ,statement_timestamp() + interval '1 days');


*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_vendor_system_profiles (reclaim_vendor_id, vendor_id, ap_vendor_number, ap_vendor_name, vendor_type, client, vendor_type_def, fee_id, profile_id, fee_name, apply_on, absolute_or_percent, fee_value, fee_inactive_flag, fee_inactive_status, source, profile_level, fee_start_date, fee_end_date, supplier_type, address, address1, address2, address3, full_address, city, state, zip_code, vendor_start_date, vendor_inactive_date, reclaim_inactive_date, vendor_contact_name, vendor_email, swell_flag, comments, reclaim_last_scan, reclaim_volume_per_week, reclaim_dollars_per_week, reclaim_on_hold, auth_for_debt, apply_max_vend_cost, auth_reason, include_system_profiles) AS (
SELECT
    xvm.reclaim_vendor_id,
    xvm.vendor_id,
    xvm.ap_vendor_number,
    xvm.ap_vendor_name,
    xvm.vendor_type,
    xvm.client,
    CASE
            WHEN xvm.vendor_type = 'I' THEN 'C1 Vendor'
            ELSE 'Customer Vendor'
        END
    vendor_type_def,
    xfd.fee_id,
    xfd.profile_id,
    xfd.fee_name,
    xfd.apply_on,
    xfd.absolute_or_percent,
    xfd.value fee_value
     --,xfd.pass_through
     --,xfd.pass_through_percent
   ,
    coalesce(xfd.status,'Active') fee_inactive_flag,
    CASE
            WHEN coalesce(xfd.status,'Active') = 'Active' THEN 'N'
            ELSE 'Y'
        END
    fee_inactive_status,
    xfd.source,
    xfd.profile_level,
    xfd.start_date fee_start_date,
    xfd.end_date fee_end_date,
    xvm.supplier_type,
    xvm.address,
    xvm.address1,
    xvm.address2,
    xvm.address3,
    xvm.address full_address --It is concatenated value
     --|| ' ' || xvm.address1 || ' '|| xvm.address2 || ' '|| xvm.address3
   ,
    xvm.city,
    xvm.state,
    xvm.zip_code,
    xvm.start_date vendor_start_date,
    xvm.inactive_date vendor_inactive_date,
    xvm.reclaim_inactive_date,
    coalesce(xvm.vendor_contact_name_ui,xvm.vendor_contact_name) vendor_contact_name,
    coalesce(xvm.vendor_email_ui,xvm.vendor_email) vendor_email,
    xvm.swell_flag,
    xvm.comments,
    xvm.reclaim_last_scan,
    xvm.reclaim_volume_per_week,
    xvm.reclaim_dollars_per_week,
    xvm.reclaim_on_hold,
    xvm.auth_for_debt,
    xvm.apply_max_vend_cost,
    xvm.auth_reason,
    'N' include_system_profiles
     /*,CASE WHEN NVL( xfd.inactive, 'N' ) = 'N' THEN
                'N'
       ELSE 'Y'
      END include_inactive_fees*/
FROM
    rcm_data.xxrcm_vendor_master xvm,
    rcm_data.xxrcm_fee_details xfd
WHERE
    xfd.reclaim_vendor_id = xvm.reclaim_vendor_id

UNION

SELECT
    NULL reclaim_vendor_id,
    NULL vendor_id,
    NULL ap_vendor_number,
    NULL ap_vendor_name,
    NULL vendor_type,
    NULL client,
    NULL vendor_type_def,
    xfd.fee_id,
    xfd.profile_id,
    xfd.fee_name,
    xfd.apply_on,
    xfd.absolute_or_percent,
    xfd.value fee_value,
    --,xfd.pass_through
    --,xfd.pass_through_percent
    coalesce(xfd.status,'Active') fee_inactive_flag,
    CASE
            WHEN coalesce(xfd.status,'Active') = 'Active' THEN 'N'
            ELSE 'Y'
        END
    fee_inactive_status,
    xfd.source,
    xfd.profile_level,
    xfd.start_date fee_start_date,
    xfd.end_date fee_end_date,
    NULL supplier_type,
    NULL address,
    NULL address1,
    NULL address2,
    NULL address3,
    NULL full_address,
    NULL city,
    NULL state,
    NULL zip_code,
    NULL vendor_start_date,
    NULL vendor_inactive_date,
    NULL reclaim_inactive_date,
    NULL vendor_contact_name,
    NULL vendor_email,
    NULL swell_flag,
    NULL comments,
    NULL reclaim_last_scan,
    NULL reclaim_volume_per_week,
    NULL reclaim_dollars_per_week,
    NULL reclaim_on_hold,
    NULL auth_for_debt,
    NULL apply_max_vend_cost,
    NULL auth_reason,
    'Y' include_system_profiles
      /*,CASE WHEN NVL( xfd.inactive, 'N' ) = 'N' THEN
                'N'
       ELSE 'Y'
      END include_inactive_fees */
FROM
    rcm_data.xxrcm_fee_details xfd
WHERE
    xfd.profile_level = 'SYSTEM'
    AND   reclaim_vendor_id IS NULL
    AND   source IN (
        'VENDOR_DEFAULT',
        'VENDOR'
    ) 
);

*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_fee_types_lkp (map_definition_id, map_code, map_desc, value, n_value1_sequence, n_value1_required_flag, n_value1_column_width, fee_name, c_value1_prompt_text, c_value1_sequence, c_value1_required_flag, c_value1_column_width, apply_on, c_value2_prompt_text, c_value2_sequence, c_value2_required_flag, c_value2_column_width, abs_or_percent, c_value3_sequence, c_value3_required_flag, c_value3_column_width, recall_fee_flag, c_value4_prompt_text, c_value4_sequence, c_value4_required_flag, c_value4_column_width, active_date_flag, active_begin_date, active_end_date) AS select def.map_definition_id,
       def.map_code,
       def.map_desc,
       val.n_value1  VALUE,
       def.n_value1_sequence,
       def.n_value1_required_flag,
       def.n_value1_column_width,
       val.c_value1 FEE_NAME,
       def.c_value1_prompt_text,
       def.c_value1_sequence,
       def.c_value1_required_flag,
       def.c_value1_column_width,
	   val.c_value2 APPLY_ON,
       def.c_value2_prompt_text,
       def.c_value2_sequence,
       def.c_value2_required_flag,
       def.c_value2_column_width,
	   val.c_value3  ABS_OR_PERCENT,
       def.c_value3_sequence,
       def.c_value3_required_flag,
       def.c_value3_column_width,
	   val.c_value4 RECALL_FEE_FLAG,
       def.c_value4_prompt_text,
       def.c_value4_sequence,
       def.c_value4_required_flag,
       def.c_value4_column_width,
	   def.active_date_flag,
       def.active_begin_date,
       def.active_end_date
FROM rcm_cmn.xxrcm_value_map_def def,
      rcm_cmn.xxrcm_value_map val
where def.map_code = 'XXRCM_FEE_NAMES'
and def.map_definition_id = val.map_definition_id
and statement_timestamp() between def.active_begin_date  and coalesce(def.active_end_date ,statement_timestamp() + interval '1 days');


CREATE OR REPLACE VIEW rcm_app.xxrcm_vendor_costing_rule_aud (rnum, vendor_costing_rule_id, field_name, new_val, old_val, versions_starttime, changed_time, who_changed) AS SELECT
    row_number() OVER () AS rnum,
    VENDOR_COSTING_RULE_ID,
    FIELD_NAME,
    REPLACE(NEW_VAL,'XX','') NEW_VAL,
    REPLACE(OLD_VAL,'XX','') OLD_VAL,
    versions_starttime,
    TO_DATE(TO_CHAR( changed_time,'DD-MON-YYYY HH24:MI:SS'),'DD-MON-YYYY HH24:MI:SS') changed_time ,
    WHO_Changed --, changed_time1
  FROM (SELECT * FROM (SELECT VENDOR_COSTING_RULE_ID,
      'EFFECTIVE_FROM' FIELD_NAME,
	coalesce(EFFECTIVE_FROM::varchar ,'XX') NEW_VAL ,
	coalesce((LEAD(EFFECTIVE_FROM) OVER (PARTITION BY VENDOR_COSTING_RULE_ID ORDER BY last_update_date DESC))::varchar ,'XX') AS OLD_VAL ,
      last_update_date versions_starttime ,
      last_update_date changed_time,
      last_updated_by      who_changed
    FROM RCM_DATA.XXRCM_VENDOR_COSTING_RULE VERSIONS BETWEEN SCN 0 and MAXVALUE
    WHERE 1           =1
    AND versions_xid IS NOT NULL
    AND VENDOR_COSTING_RULE_ID = sys_context('RCMCTX', 'filter')
    /* AND versions_operation  = 'U' */
 ) alias10  WHERE NEW_VAL <> OLD_VAL

UNION ALL

    SELECT * FROM (SELECT VENDOR_COSTING_RULE_ID,
      'EFFECTIVE_TO' FIELD_NAME,
      coalesce(EFFECTIVE_TO::varchar ,'XX') NEW_VAL ,
      coalesce((LEAD(EFFECTIVE_TO) OVER (PARTITION BY VENDOR_COSTING_RULE_ID ORDER BY last_update_date DESC))::varchar,'XX') AS OLD_VAL ,
      last_update_date versions_starttime ,
      last_update_date changed_time,
      last_updated_by       who_changed
    FROM RCM_DATA.XXRCM_VENDOR_COSTING_RULE VERSIONS BETWEEN SCN 0 and MAXVALUE
    WHERE 1           =1
    AND versions_xid IS NOT NULL
    AND VENDOR_COSTING_RULE_ID = sys_context('RCMCTX', 'filter')
    /* AND versions_operation  = 'U' */
 ) alias17  WHERE NEW_VAL <> OLD_VAL
) alias18
WHERE coalesce(NEW_VAL,'ZXY') <> coalesce(OLD_VAL,'!ZXY')
AND ( sys_context('RCMCTX', 'filter') is null
      AND  1=1
	  OR VENDOR_COSTING_RULE_ID = sys_context('RCMCTX', 'filter')
	 )
--AND VENDOR_COSTING_RULE_ID = sys_context('RCMCTX', 'filter')
and versions_starttime is not null 
  ORDER BY
    versions_starttime DESC;

*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_vendor_profile_fee_stg (seq_id, batch_id, file_name, reclaim_vendor_id, ap_vendor_id, ap_vendor_number, ap_vendor_name, fee_id, fee_name, apply_on, absolute_or_percent, value, fee_inactive_flag, fee_start_date, fee_end_date, profile_level, profile_id, process_status, process_message, created_by, creation_date, last_updated_by, last_update_date, request_id, record_source, total_rows, success_rows, error_rows) AS ( SELECT seq_id
        --,null file_id
        ,batch_id
        ,file_name
        ,reclaim_vendor_id
        --,reclaim_customer_id
        --,party_id
        --,party_site_id
        ,ap_vendor_id
        ,ap_vendor_number
        ,ap_vendor_name
        ,fee_id
        ,fee_name
        ,apply_on
        ,absolute_or_percent
        ,value
        --,pass_through
        --,pass_through_percent
        ,status fee_inactive_flag
        ,start_date fee_start_date
        ,end_date  fee_end_date
		,profile_level
		,profile_id
        --,chain
        --,store
        ,process_status
        ,process_message
        ,created_by
        ,creation_date
        ,last_updated_by
        ,last_update_date
        ,request_id
        ,'FILE' record_source
        ,COUNT(1) OVER ( PARTITION BY batch_id ) total_rows
		,SUM( CASE WHEN process_status = 'S' THEN 1 ELSE 0 END ) OVER ( PARTITION BY batch_id ) success_rows
		,SUM( CASE WHEN process_status = 'E' THEN 1 ELSE 0 END ) OVER ( PARTITION BY batch_id ) error_rows
   FROM rcm_data.XXRCM_VENDOR_PROF_FEE_STG
);


*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_vendor_master_ac_vw (reclaim_vendor_id, vendor_id, ap_vendor_number, ap_vendor_name, vendor_type, client) AS (
SELECT
    xvm.reclaim_vendor_id,
    xvm.vendor_id,
    xvm.ap_vendor_number,
    xvm.ap_vendor_name,
    xvm.vendor_type,
    xvm.client
FROM
    rcm_data.xxrcm_vendor_master xvm
WHERE
    xvm.reclaim_inactive_date IS NULL
    OR   xvm.reclaim_inactive_date > date_trunc('day', statement_timestamp())
);

*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_vendor_costing_def_v (vendor_costing_rule_id, ap_vendor, facility_id, facility, gl_code, master_upc, master_item_id, whse_item_id, whse_item_code, ssic, conditional_validation_yes_no, rank, costing_method_id, costing_method_name, effective_from, effective_to, conditional_validation_id, grouping, condition, arithemetic_operand, operand, value) AS (SELECT
    vc.vendor_costing_rule_id,
    vc.ap_vendor,
	vc.facility_id,
    vc.facility,
    vc.gl_code,
    vc.master_upc,
    vc.master_item_id,
    vc.whse_item_id,
    vc.whse_item_code,
    vc.ssic,
    vc.conditional_validation_yes_no,
    vc.rank,
    vc.costing_method_id,
    vc.costing_method_name,
    vc.effective_from,
    vc.effective_to,
    cv.conditional_validation_id,
    cv.grouping,
    cv.condition,
    cv.arithemetic_operand,
    cv.operand,
    cv.value
FROM rcm_data.xxrcm_vendor_costing_rule vc
LEFT OUTER JOIN rcm_data.xxrcm_conditional_validation cv ON (vc.vendor_costing_rule_id = cv.vendor_costing_rule_id) );


*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_vendor_dtls_lov_v (ap_vendor_number, ap_vendor_name) AS (
SELECT
    (ap_vendor_number)::numeric  ap_vendor_number,
    ap_vendor_name
FROM
    rcm_data.xxrcm_vendor_master
WHERE
    vendor_type = 'I'
    --AND   (reclaim_inactive_date IS NULL OR reclaim_inactive_date >= SYSDATE)
)
ORDER BY
    1 ASC;

*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_vendor_master_v (ap_vendor_number, ap_vendor_name) AS select (ap_vendor_number)::numeric  ap_vendor_number, ap_vendor_name
FROM rcm_data.xxrcm_vendor_master
where vendor_type = 'I'
and (reclaim_inactive_date is NULL or reclaim_inactive_date > statement_timestamp());

*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_dflt_item_disp_v (map_definition_id, map_code, map_desc, cp_group_code, c_value1_sequence, c_value1_required_flag, c_value1_column_width, nielsen_child_group_descr, c_value2_prompt_text, c_value2_sequence, c_value2_required_flag, c_value2_column_width, prod_disposition, c_value3_prompt_text, c_value3_sequence, c_value3_required_flag, c_value3_column_width, active_date_flag, active_begin_date, active_end_date) AS select def.map_definition_id,
       def.map_code,
       def.map_desc,
       val.c_value1  cp_group_code,
       def.c_value1_sequence,
       def.c_value1_required_flag,
       def.c_value1_column_width,
       val.c_value2 NIELSEN_CHILD_GROUP_DESCR,
       def.c_value2_prompt_text,
       def.c_value2_sequence,
       def.c_value2_required_flag,
       def.c_value2_column_width,
	   val.c_value3 prod_disposition,
       def.c_value3_prompt_text,
       def.c_value3_sequence,
       def.c_value3_required_flag,
       def.c_value3_column_width,
       def.active_date_flag,
       def.active_begin_date,
       def.active_end_date
FROM rcm_cmn.xxrcm_value_map_def def, 
      rcm_cmn.xxrcm_value_map val
where def.map_code = 'XXRCM_TOB_CREDIT_METHOD'
and def.map_definition_id = val.map_definition_id
and def.active_begin_date < date_trunc('day', statement_timestamp())
and (def.active_end_date > statement_timestamp() or def.active_end_date is null);


*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_scan_stg_vw (record_id, reference_id, customer_store_num, rclm_customer_id, cs_cust_number, chain_number, chain_name, cs_cust_name, original_upc, upc, upc_type, master_item_id, item_type, whse_item_code, whse_item_id, pack, customer_item_code, customer_item_id, reclaim_center_code, reclaim_center_name, loc_type, scan_date, scan_status, vendor_number, reclaim_vendor_num, reclaim_vendor_id, reclaim_vendor_name, units, scan_quantity, customer_dept, client_group, rclm_customer_grp_num, rclm_customer_grp_id, rclm_customer_grp_name, disposition_type, disposition, store_indicator, state_indicator, auth_number, facility, facility_name, item_description, unit_cost, unit_retail, gl_code, gl_description, nielsen_category, bottle_deposit, department, division_nbr, division_name, trans_control_num, box_number, ssic, irc_code, ap2_number, item_size_uom, item_size, cust_credit_percent, haz_flag, private_label, vend_deduct_unit_cost, cust_credit_unit_cost, cust_credit_auth_flag, vend_deduct_auth_flag, reclaim_as_service_flag, swell_flag, recall_class, recall_flag, file_name, tob_state_code, tob_state_tax, record_count, sort_code, warehouse_name, vendor_cost, cust_invoice_num, cust_invoice_date, cust_inv_process_flag, cust_credit_amount, cust_inv_error_msg, vend_invoice_num, control_number, vend_invoice_date, vend_inv_process_flag, vend_deduct_amount, vend_inv_error_msg, scan_status_start_dt, scan_status_end_dt, fee_grp_id, rule_exp_id, rule_description, tobacco_type, tobacco_credit_method, rule_comments, attribute1, attribute2, attribute3, attribute4, attribute5, attribute6, attribute7, attribute8, attribute9, attribute10, attribute11, attribute12, attribute13, attribute14, attribute15, scan_source, creation_date, created_by, last_update_date, last_updated_by, process_status, error_message, request_id, fiscal_year, fiscal_week, cust_scan_fee_item, cust_scan_fee_summ, vend_scan_fee_item, vend_scan_fee_summ, billing_date, comments, cust_pass_thru, create_rule, unit_factor, file_id, piece_in_pack, pack_in_carton, vndr_deduct_reason) AS (SELECT record_id
        ,reference_id
        ,customer_store_num
        ,rclm_customer_id
        ,cs_cust_number
        ,chain_number
        ,chain_name
        ,cs_cust_name
        ,original_upc
        ,upc
        ,upc_type
        ,master_item_id
        ,item_type
        ,whse_item_code
        ,whse_item_id
        ,pack
        ,customer_item_code
        ,customer_item_id
        ,reclaim_center_code
        ,reclaim_center_name
        ,loc_type
        ,scan_date
        ,scan_status
        ,vendor_number
        ,reclaim_vendor_num
        ,reclaim_vendor_id
        ,reclaim_vendor_name
        ,units
        ,scan_quantity
        ,customer_dept
        ,client_group
        ,rclm_customer_grp_num
        ,rclm_customer_grp_id
        ,rclm_customer_grp_name
        ,disposition_type
        ,disposition
        ,store_indicator
        ,state_indicator
        ,auth_number
        ,facility
        ,facility_name
        ,item_description
        ,unit_cost
        ,unit_retail
        ,gl_code
        ,gl_description
        ,nielsen_category
        ,bottle_deposit
        ,department
        ,division_nbr
        ,division_name
        ,trans_control_num
        ,box_number
        ,ssic
        ,irc_code
        ,ap2_number
        ,item_size_uom
        ,item_size
        ,cust_credit_percent
        ,haz_flag
        ,private_label
        ,vend_deduct_unit_cost
        ,cust_credit_unit_cost
        ,cust_credit_auth_flag
        ,vend_deduct_auth_flag
        ,reclaim_as_service_flag
        ,swell_flag
        ,recall_class
        ,recall_flag
        ,file_name
        ,tob_state_code
        ,tob_state_tax
        ,record_count
        ,sort_code
        ,warehouse_name
        ,vendor_cost
        ,cust_invoice_num
        ,cust_invoice_date
        ,cust_inv_process_flag
        ,cust_credit_amount
        ,cust_inv_error_msg
        ,vend_invoice_num
        ,control_number
        ,vend_invoice_date
        ,vend_inv_process_flag
        ,vend_deduct_amount
        ,vend_inv_error_msg
        ,scan_status_start_dt
        ,scan_status_end_dt
        ,fee_grp_id
        ,rule_exp_id
        ,rule_description
        ,tobacco_type
        ,tobacco_credit_method
        ,rule_comments
        ,attribute1
        ,attribute2
        ,attribute3
        ,attribute4
        ,attribute5
        ,attribute6
        ,attribute7
        ,attribute8
        ,attribute9
        ,attribute10
        ,attribute11
        ,attribute12
        ,attribute13
        ,attribute14
        ,attribute15
        ,scan_source
        ,creation_date
        ,created_by
        ,last_update_date
        ,last_updated_by
        ,process_status
        ,error_message
        ,request_id
        ,fiscal_year
        ,fiscal_week
        ,cust_scan_fee_item
        ,cust_scan_fee_summ
        ,vend_scan_fee_item
        ,vend_scan_fee_summ
        ,billing_date
        ,comments
        ,cust_pass_thru
        ,create_rule
        ,unit_factor
		,file_id
		,piece_in_pack
		,pack_in_carton
		,vndr_deduct_reason
    FROM rcm_data.xxrcm_scan_stg xss
  WHERE process_status IN ( 'N', 'E' )
    AND NOT EXISTS ( SELECT 1
	                  FROM rcm_data.xxrcm_scan_stg xss1
					 WHERE xss.record_id = xss1.reference_id
				   )
 );


CREATE OR REPLACE VIEW rcm_app.xxrcm_scan_stg_aud (rnum, record_id, rclm_customer_id, master_item_id, fee_grp_id, upc, field_name, new_val, old_val, versions_starttime, changed_time, who_changed) AS SELECT
	row_number() OVER () AS rnum,
	record_id,
	rclm_customer_id,
	master_item_id,
	fee_grp_id,
	upc,
	field_name,
	REPLACE(NEW_VAL,'XX','') NEW_VAL,
	REPLACE(OLD_VAL,'XX','') OLD_VAL,
	versions_starttime,
	TO_DATE(TO_CHAR( changed_time,'DD-MON-YYYY HH24:MI:SS'),'DD-MON-YYYY HH24:MI:SS') changed_time ,
	who_changed
FROM (
	   SELECT * FROM (SELECT
		record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		upc,
		'CS_CUST_NUMBER' FIELD_NAME,
		coalesce(cast(cs_cust_number as varchar(100)) ,'XX') NEW_VAL,
		coalesce(LEAD(cast(cs_cust_number as varchar(100))) OVER (PARTITION BY RECORD_ID ORDER BY versions_starttime DESC) ,'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
	    last_updated_by WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_STG VERSIONS BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND (  record_id = sys_context('RCMCTX', 'filter'))
	 ) alias14  WHERE NEW_VAL <> OLD_VAL
     
UNION ALL

	 SELECT * FROM (SELECT
		record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		upc,
		'ORIGINAL_UPC' FIELD_NAME,
		coalesce(cast(original_upc as varchar(100)) ,'XX') NEW_VAL,
		coalesce(LEAD(cast(original_upc as varchar(100))) OVER (PARTITION BY RECORD_ID ORDER BY versions_starttime DESC) ,'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
	    last_updated_by WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_STG VERSIONS BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND (  record_id = sys_context('RCMCTX', 'filter')) 
	 ) alias25  WHERE NEW_VAL <> OLD_VAL
     
UNION ALL

	 SELECT * FROM (SELECT
		record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		upc,
		'BOX_NUMBER' FIELD_NAME,
		coalesce(cast(box_number as varchar(100)) ,'XX') NEW_VAL,
		coalesce(LEAD(cast(box_number as varchar(100))) OVER (PARTITION BY RECORD_ID ORDER BY versions_starttime DESC) ,'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
	    last_updated_by WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_STG VERSIONS BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND (  record_id = sys_context('RCMCTX', 'filter')) 
		) alias36  WHERE NEW_VAL <> OLD_VAL
	 
UNION ALL

		SELECT * FROM (SELECT
		record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		upc,
		'SCAN_QUANTITY' FIELD_NAME,
		coalesce(cast(scan_quantity as varchar(100)) ,'XX') NEW_VAL,
		coalesce(cast(LEAD(cast(scan_quantity as varchar(100))) OVER (PARTITION BY RECORD_ID ORDER BY versions_starttime DESC) as varchar(100)) ,'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
	    last_updated_by WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_STG VERSIONS BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND (  record_id = sys_context('RCMCTX', 'filter')) 
	 ) alias49  WHERE NEW_VAL <> OLD_VAL
	 
UNION ALL

		SELECT * FROM (SELECT
		record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		upc,
		'SCAN_DATE' FIELD_NAME,
		coalesce(cast(scan_date as varchar(100)) ,'XX') NEW_VAL,
		coalesce(LEAD(cast(scan_date as varchar(100))) OVER (PARTITION BY RECORD_ID ORDER BY versions_starttime DESC) ,'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
	    last_updated_by WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_STG VERSIONS BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND (  record_id = sys_context('RCMCTX', 'filter')) 
	 ) alias60  WHERE NEW_VAL <> OLD_VAL
	 
UNION ALL

		SELECT * FROM ( SELECT
		record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		upc,
		'COMMENTS' FIELD_NAME,
		coalesce(cast(comments as varchar(100)) ,'XX') NEW_VAL,
		coalesce(LEAD(cast(comments as varchar(100))) OVER (PARTITION BY RECORD_ID ORDER BY versions_starttime DESC) ,'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
	    last_updated_by WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_STG VERSIONS BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND (  record_id = sys_context('RCMCTX', 'filter')) 
	 ) alias71  WHERE NEW_VAL <> OLD_VAL
	 
UNION ALL

	 SELECT * FROM (SELECT
		record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		upc,
		'AP2_NUMBER' FIELD_NAME,
		coalesce(cast(ap2_number as varchar(100)) ,'XX') NEW_VAL,
		coalesce(LEAD(cast(ap2_number as varchar(100))) OVER (PARTITION BY RECORD_ID ORDER BY versions_starttime DESC) ,'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
	    last_updated_by WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_STG VERSIONS BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND (  record_id = sys_context('RCMCTX', 'filter')) 
	 ) alias82  WHERE NEW_VAL <> OLD_VAL
	 
UNION ALL

	 SELECT * FROM (SELECT
		record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		upc,
		'VENDOR_NUMBER' FIELD_NAME,
		coalesce(cast(vendor_number as varchar(100)) ,'XX') NEW_VAL,
		coalesce(LEAD(cast(vendor_number as varchar(100))) OVER (PARTITION BY RECORD_ID ORDER BY versions_starttime DESC) ,'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
	    last_updated_by WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_STG VERSIONS BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND (  record_id = sys_context('RCMCTX', 'filter')) 
	 ) alias93  WHERE NEW_VAL <> OLD_VAL
	 
UNION ALL

	 SELECT * FROM (SELECT
		record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		upc,
		'VENDOR_COST' FIELD_NAME,
		coalesce(cast(vendor_cost as varchar(100)) ,'XX') NEW_VAL,
		coalesce(LEAD(cast(vendor_cost as varchar(100))) OVER (PARTITION BY RECORD_ID ORDER BY versions_starttime DESC) ,'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
	    last_updated_by WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_STG VERSIONS BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND (  record_id = sys_context('RCMCTX', 'filter')) 
	 ) alias104  WHERE NEW_VAL <> OLD_VAL
	 
UNION ALL

	 SELECT * FROM (SELECT
		record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		upc,
		'LOC_TYPE' FIELD_NAME,
		coalesce(cast(loc_type as varchar(100)) ,'XX') NEW_VAL,
		coalesce(LEAD(cast(loc_type as varchar(100))) OVER (PARTITION BY RECORD_ID ORDER BY versions_starttime DESC) ,'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
	    last_updated_by WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_STG VERSIONS BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND (  record_id = sys_context('RCMCTX', 'filter')) 
	 ) alias115  WHERE NEW_VAL <> OLD_VAL
	 
UNION ALL

	 SELECT * FROM (SELECT
		record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		upc,
		'CLIENT_GROUP' FIELD_NAME,
		coalesce(cast(client_group as varchar(100)) ,'XX') NEW_VAL,
		coalesce(LEAD(cast(client_group as varchar(100))) OVER (PARTITION BY RECORD_ID ORDER BY versions_starttime DESC) ,'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
	    last_updated_by WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_STG VERSIONS BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND (  record_id = sys_context('RCMCTX', 'filter')) 
	 ) alias126  WHERE NEW_VAL <> OLD_VAL
	 
UNION ALL

	 SELECT * FROM (SELECT
		record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		upc,
		'DEPARTMENT' FIELD_NAME,
		coalesce(cast(department as varchar(100)) ,'XX') NEW_VAL,
		coalesce(LEAD(cast(department as varchar(100))) OVER (PARTITION BY RECORD_ID ORDER BY versions_starttime DESC) ,'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
	    last_updated_by WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_STG VERSIONS BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND (  record_id = sys_context('RCMCTX', 'filter')) 
	 ) alias137  WHERE NEW_VAL <> OLD_VAL
	 
UNION ALL

	 SELECT * FROM (SELECT
		record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		upc,
		'DISPOSITION' FIELD_NAME,
		coalesce(cast(disposition as varchar(100)) ,'XX') NEW_VAL,
		coalesce(LEAD(cast(disposition as varchar(100))) OVER (PARTITION BY RECORD_ID ORDER BY versions_starttime DESC) ,'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
	    last_updated_by WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_STG VERSIONS BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND (  record_id = sys_context('RCMCTX', 'filter')) 
	 ) alias148  WHERE NEW_VAL <> OLD_VAL
	 
UNION ALL

	 SELECT * FROM (SELECT
		record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		upc,
		'WAREHOUSE_NAME' FIELD_NAME,
		coalesce(cast(warehouse_name as varchar(100)) ,'XX') NEW_VAL,
		coalesce(LEAD(cast(warehouse_name as varchar(100))) OVER (PARTITION BY RECORD_ID ORDER BY versions_starttime DESC) ,'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
	    last_updated_by WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_STG VERSIONS BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND (  record_id = sys_context('RCMCTX', 'filter')) 
	 ) alias159  WHERE NEW_VAL <> OLD_VAL
	 
UNION ALL

	 SELECT * FROM (SELECT
		record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		upc,
		'IRC_CODE' FIELD_NAME,
		coalesce(cast(irc_code as varchar(100)) ,'XX') NEW_VAL,
		coalesce(LEAD(cast(irc_code as varchar(100))) OVER (PARTITION BY RECORD_ID ORDER BY versions_starttime DESC) ,'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
	    last_updated_by WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_STG VERSIONS BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND (  record_id = sys_context('RCMCTX', 'filter')) 
	 ) alias170  WHERE NEW_VAL <> OLD_VAL
	 
UNION ALL

	 SELECT * FROM (SELECT
		record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		upc,
		'AUTH_NUMBER' FIELD_NAME,
		coalesce(cast(auth_number as varchar(100)) ,'XX') NEW_VAL,
		coalesce(LEAD(cast(auth_number as varchar(100))) OVER (PARTITION BY RECORD_ID ORDER BY versions_starttime DESC) ,'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
	    last_updated_by WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_STG VERSIONS BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND (  record_id = sys_context('RCMCTX', 'filter')) 
	 ) alias181  WHERE NEW_VAL <> OLD_VAL
	 
UNION ALL

	 SELECT * FROM (SELECT
		record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		upc,
		'TRANS_CONTROL_NUM' FIELD_NAME,
		coalesce(cast(trans_control_num as varchar(100)) ,'XX') NEW_VAL,
		coalesce(LEAD(cast(trans_control_num as varchar(100))) OVER (PARTITION BY RECORD_ID ORDER BY versions_starttime DESC) ,'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
	    last_updated_by WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_STG VERSIONS BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND (  record_id = sys_context('RCMCTX', 'filter')) 
	 ) alias192  WHERE NEW_VAL <> OLD_VAL
	 
UNION ALL

	 SELECT * FROM (SELECT
		record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		upc,
		'STORE_INDICATOR' FIELD_NAME,
		coalesce(cast(store_indicator as varchar(100)) ,'XX') NEW_VAL,
		coalesce(LEAD(cast(store_indicator as varchar(100))) OVER (PARTITION BY RECORD_ID ORDER BY versions_starttime DESC) ,'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
	    last_updated_by WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_STG VERSIONS BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND (  record_id = sys_context('RCMCTX', 'filter')) 
	 ) alias203  WHERE NEW_VAL <> OLD_VAL
	 
UNION ALL

	 SELECT * FROM (SELECT
		record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		upc,
		'STATE_INDICATOR' FIELD_NAME,
		coalesce(cast(state_indicator as varchar(100)) ,'XX') NEW_VAL,
		coalesce(LEAD(cast(state_indicator as varchar(100))) OVER (PARTITION BY RECORD_ID ORDER BY versions_starttime DESC) ,'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
	    last_updated_by WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_STG VERSIONS BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND (  record_id = sys_context('RCMCTX', 'filter')) 
	 ) alias214  WHERE NEW_VAL <> OLD_VAL
	 
UNION ALL

	 SELECT * FROM (SELECT
		record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		upc,
		'SORT_CODE' FIELD_NAME,
		coalesce(cast(sort_code as varchar(100)) ,'XX') NEW_VAL,
		coalesce(LEAD(cast(sort_code as varchar(100))) OVER (PARTITION BY RECORD_ID ORDER BY versions_starttime DESC) ,'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
	    last_updated_by WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_STG VERSIONS BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND (  record_id = sys_context('RCMCTX', 'filter')) 
	 ) alias225  WHERE NEW_VAL <> OLD_VAL
	) alias226
WHERE coalesce(NEW_VAL,'ZXY') <> coalesce(OLD_VAL,'!ZXY') 
ORDER BY
versions_starttime DESC;


CREATE OR REPLACE VIEW rcm_app.xxrcm_scan_master_aud (rnum, scan_master_id, stg_record_id, rclm_customer_id, master_item_id, fee_grp_id, cs_cust_number, upc, field_name, new_val, old_val, versions_starttime, changed_time, who_changed) AS SELECT
	row_number() OVER () AS rnum,
	scan_master_id,
	stg_record_id,
	rclm_customer_id,
	master_item_id,
	fee_grp_id,
	cs_cust_number,
	upc,
	field_name,
	REPLACE(NEW_VAL,'XX','') NEW_VAL,
	REPLACE(OLD_VAL,'XX','') OLD_VAL,
	versions_starttime,
	TO_DATE(TO_CHAR( changed_time,'DD-MON-YYYY HH24:MI:SS'),'DD-MON-YYYY HH24:MI:SS') changed_time ,
	who_changed
FROM (
	   SELECT * FROM (SELECT
		scan_master_id,
		stg_record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		cs_cust_number,
		upc,
		'SCAN_QUANTITY' FIELD_NAME,
		coalesce(cast(SCAN_QUANTITY as varchar(100)) ,'XX') NEW_VAL ,
		coalesce(LEAD(cast(SCAN_QUANTITY as varchar(100))) OVER (PARTITION BY SCAN_MASTER_ID ORDER BY versions_starttime DESC),'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
		LAST_UPDATED_BY WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_MASTER VERSIONS
		  BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND scan_master_id = sys_context('RCMCTX', 'filter')
	 /* AND versions_operation  = 'U' */
 ) alias13  WHERE NEW_VAL <> OLD_VAL

UNION ALL

	 SELECT * FROM (SELECT
		scan_master_id,
		stg_record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		cs_cust_number,
		upc,
		'VEND_DEDUCT_AMOUNT' FIELD_NAME,
		coalesce(cast(VEND_DEDUCT_AMOUNT as varchar(100)) ,'XX') NEW_VAL ,
		coalesce(LEAD(cast(VEND_DEDUCT_AMOUNT as varchar(100))) OVER (PARTITION BY SCAN_MASTER_ID ORDER BY versions_starttime DESC) ,'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
		LAST_UPDATED_BY WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_MASTER VERSIONS
		BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND scan_master_id = sys_context('RCMCTX', 'filter')
	 /* AND versions_operation  = 'U' */
 ) alias23  WHERE NEW_VAL <> OLD_VAL
     
UNION ALL

	 SELECT * FROM (SELECT
		scan_master_id,
		stg_record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		cs_cust_number,
		upc,
		'CUST_CREDIT_UNIT_COST' FIELD_NAME,
		coalesce(cast(CUST_CREDIT_UNIT_COST as varchar(100)) ,'XX') NEW_VAL ,
		coalesce(LEAD(cast(CUST_CREDIT_UNIT_COST as varchar(100))) OVER (PARTITION BY SCAN_MASTER_ID ORDER BY versions_starttime DESC),'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
		LAST_UPDATED_BY WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_MASTER VERSIONS
	 BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND scan_master_id = sys_context('RCMCTX', 'filter')
	 /* AND versions_operation  = 'U' */
 ) alias33  WHERE NEW_VAL <> OLD_VAL
	 
UNION ALL

	 SELECT * FROM (SELECT
		scan_master_id,
		stg_record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		cs_cust_number,
		upc,
		'SCAN_STATUS' FIELD_NAME,
		coalesce(cast(SCAN_STATUS as varchar(100)) ,'XX') NEW_VAL ,
		coalesce(cast(LEAD(cast(SCAN_STATUS as varchar(100))) OVER (PARTITION BY SCAN_MASTER_ID ORDER BY versions_starttime DESC) as varchar(100)) ,'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
		LAST_UPDATED_BY WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_MASTER VERSIONS
	 BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND scan_master_id = sys_context('RCMCTX', 'filter')
	 /* AND versions_operation  = 'U' */
 ) alias45  WHERE NEW_VAL <> OLD_VAL
	 
UNION ALL

	 SELECT * FROM (SELECT
		scan_master_id,
		stg_record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		cs_cust_number,
		upc,
		'SCAN_STATUS_START_DT' FIELD_NAME,
		coalesce(cast(SCAN_STATUS_START_DT as varchar(100)) ,'XX') NEW_VAL ,
		coalesce(LEAD(cast(SCAN_STATUS_START_DT as varchar(100))) OVER (PARTITION BY SCAN_MASTER_ID ORDER BY versions_starttime DESC) ,'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
		LAST_UPDATED_BY WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_MASTER VERSIONS
	 BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND scan_master_id = sys_context('RCMCTX', 'filter')
	 /* AND versions_operation  = 'U' */
 ) alias55  WHERE NEW_VAL <> OLD_VAL
	 
UNION ALL

	 SELECT * FROM (SELECT
		scan_master_id,
		stg_record_id,
		rclm_customer_id,
		master_item_id,
		fee_grp_id,
		cs_cust_number,
		upc,
		'SCAN_STATUS_END_DT' FIELD_NAME,
		coalesce(cast(SCAN_STATUS_END_DT as varchar(100)) ,'XX') NEW_VAL ,
		coalesce(LEAD(cast(SCAN_STATUS_END_DT as varchar(100))) OVER (PARTITION BY SCAN_MASTER_ID ORDER BY versions_starttime DESC) ,'XX') AS OLD_VAL ,
		versions_starttime ,
		versions_starttime changed_time,
		LAST_UPDATED_BY WHO_Changed
	 FROM RCM_DATA.XXRCM_SCAN_MASTER VERSIONS
	 BETWEEN SCN MINVALUE and MAXVALUE
	 WHERE 1           =1
	 AND versions_xid IS NOT NULL
	 AND scan_master_id = sys_context('RCMCTX', 'filter')
	 /* AND versions_operation  = 'U' */
 ) alias65  WHERE NEW_VAL <> OLD_VAL
	) alias66
WHERE coalesce(NEW_VAL,'ZXY') <> coalesce(OLD_VAL,'!ZXY')
AND ( sys_context('RCMCTX', 'filter') is null
AND  1=1
  OR scan_master_id = sys_context('RCMCTX', 'filter')
 )
--AND scan_master_id = sys_context('RCMCTX', 'filter')
 
ORDER BY versions_starttime DESC;


*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_value_map_actions_lookup (map_definition_id, map_code, map_desc, source_data, c_value1_prompt_text, create_base_item, c_value2_prompt_text, update_base_item, c_value3_prompt_text, create_cust_item, c_value4_prompt_text, update_cust_item, c_value5_prompt_text, customer_name, c_value6_prompt_text, chain_num, c_value7_prompt_text, active_date_flag, active_begin_date, active_end_date) AS (select def.map_definition_id,
       def.map_code,
       def.map_desc,
      val.c_value1 SOURCE_DATA,
       def.c_value1_prompt_text,
	   val.c_value2 CREATE_BASE_ITEM,
       def.c_value2_prompt_text,
	   --
	   val.c_value3 UPDATE_BASE_ITEM,
       def.c_value3_prompt_text,
        val.c_value4 CREATE_CUST_ITEM,
       def.C_VALUE4_PROMPT_TEXT,
       val.c_value5 UPDATE_CUST_ITEM,
       def.C_VALUE5_PROMPT_TEXT,
        val.c_value6 CUSTOMER_NAME,
       def.C_VALUE6_PROMPT_TEXT,
       --
       val.c_value7 CHAIN_NUM,
       def.C_VALUE7_PROMPT_TEXT,
       --
       def.active_date_flag,
       def.active_begin_date,
       def.active_end_date
FROM rcm_cmn.xxrcm_value_map_def def,
      rcm_cmn.xxrcm_value_map val
where def.map_code = 'XXRCM_ITEM_FUNC_BY_SOURCE'
and def.map_definition_id = val.map_definition_id
and statement_timestamp() between def.active_begin_date  and coalesce(def.active_end_date ,statement_timestamp() + interval '1 days') );


*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_item_disposition_vw (map_definition_id, map_code, map_desc, nielsen_child_group_code, c_value1_prompt_text, nielsen_child_group_descr, c_value2_prompt_text, item_disposition, c_value3_prompt_text, active_date_flag, active_begin_date, active_end_date) AS (select def.map_definition_id,
       def.map_code,
       def.map_desc,
      val.c_value1 NIELSEN_CHILD_GROUP_CODE,
       def.c_value1_prompt_text,
       val.c_value2 NIELSEN_CHILD_GROUP_DESCR,
       def.c_value2_prompt_text,
       val.c_value3 ITEM_DISPOSITION ,
       def.c_value3_prompt_text,
       def.active_date_flag,
       def.active_begin_date,
       def.active_end_date
FROM rcm_cmn.xxrcm_value_map_def def,
      rcm_cmn.xxrcm_value_map val
where def.map_code = 'XXRCM_ITM_DISPOSE_NLSN_CHILD' -- 'XXRCM_NIELSEN_CHILD_GROUP'-- 'XXRCM_ITEM_DISPOSITION'-- 'XXRCM_TOB_CIGARETTE_TAX' -- 'XXRCM_TOB_CREDIT_METHOD' -- 'XXRCM_GL_LIST'-- 'XXRCM_KEY_ITEM_FIELDS'
and def.map_definition_id = val.map_definition_id
and statement_timestamp() between def.active_begin_date  and coalesce(def.active_end_date ,statement_timestamp() + interval '1 days') );


*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_nielsen_child_group_vw (map_definition_id, map_code, map_desc, cs_nielsen_num, c_value1_prompt_text, nielsen_child_group_code, c_value2_prompt_text, nielsen_child_group_descr, c_value3_prompt_text, active_date_flag, active_begin_date, active_end_date) AS (select def.map_definition_id,
       def.map_code,
       def.map_desc,
      val.c_value1 CS_NIELSEN_NUM,
       def.c_value1_prompt_text,
	   val.c_value2 NIELSEN_CHILD_GROUP_CODE,
       def.c_value2_prompt_text,
	   --
	   val.c_value3 NIELSEN_CHILD_GROUP_DESCR,
       def.c_value3_prompt_text,
       def.active_date_flag,
       def.active_begin_date,
       def.active_end_date
FROM rcm_cmn.xxrcm_value_map_def def,
      rcm_cmn.xxrcm_value_map val
where def.map_code = 'XXRCM_NIELSEN_CHILD_GROUP'-- 'XXRCM_NIELSEN_CHILD_GROUP'-- 'XXRCM_ITEM_DISPOSITION'-- 'XXRCM_TOB_CIGARETTE_TAX' -- 'XXRCM_TOB_CREDIT_METHOD' -- 'XXRCM_GL_LIST'-- 'XXRCM_KEY_ITEM_FIELDS'
and def.map_definition_id = val.map_definition_id
and statement_timestamp() between def.active_begin_date  and coalesce(def.active_end_date ,statement_timestamp() + interval '1 days') );

*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_tob_cigarette_tax (state_code, state_descr, tax_rate, tax_method_code, tax_method_descr, d_value2) AS ( SELECT
    val.c_value1   state_code,
    val.c_value2   state_descr,
    val.n_value1   tax_rate,
    val.c_value3   tax_method_code,
    val.c_value4   tax_method_descr,
    val.d_value2
    FROM
    rcm_cmn.xxrcm_value_map_def def,
    rcm_cmn.xxrcm_value_map val
   WHERE
    def.map_code = 'XXRCM_TOB_CIGARETTE_TAX'
       AND def.map_definition_id = val.map_definition_id
     and val.d_value2 is null
  );

 *****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_gl_num_vw (map_definition_id, map_code, map_desc, gl_number, c_value1_prompt_text, gl_name, c_value2_prompt_text, icc_type, c_value3_prompt_text, active_date_flag, active_begin_date, active_end_date) AS (select def.map_definition_id,
       def.map_code,
       def.map_desc,
      val.c_value1 gl_number,
       def.c_value1_prompt_text,
	   val.c_value2 gl_name,
       def.c_value2_prompt_text,
       val.c_value3 icc_type,
       def.c_value3_prompt_text,
       def.active_date_flag,
       def.active_begin_date,
       def.active_end_date
FROM rcm_cmn.xxrcm_value_map_def def,
      rcm_cmn.xxrcm_value_map val
where def.map_code = 'XXRCM_GL_LIST'
and def.map_definition_id = val.map_definition_id);

*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_tob_credit_method (map_definition_id, map_code, map_desc, tobacco_type, c_value1_prompt_text, tobacco_credit_method, c_value2_prompt_text, active_date_flag, active_begin_date, active_end_date) AS (
select def.map_definition_id,
       def.map_code,
       def.map_desc,
      val.c_value1 TOBACCO_TYPE,
       def.c_value1_prompt_text,
	   val.c_value2 TOBACCO_CREDIT_METHOD,
       def.c_value2_prompt_text,
       def.active_date_flag,
       def.active_begin_date,
       def.active_end_date
FROM rcm_cmn.xxrcm_value_map_def def,
      rcm_cmn.xxrcm_value_map val
where def.map_code = 'XXRCM_TOB_CREDIT_METHOD'
and def.map_definition_id = val.map_definition_id
and statement_timestamp() between def.active_begin_date  and coalesce(def.active_end_date ,statement_timestamp() + interval '1 days') );

*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_clnt_grp_cal_assn_vw (cust_cal_name, cust_grp) AS (SELECT mp.c_value1  Cust_Cal_Name,N_VALUE1  CUST_GRP
                        FROM rcm_cmn.xxrcm_value_map_def def, rcm_cmn.xxrcm_value_map mp
                       where def.map_definition_id = mp.map_definition_id
                         and map_code = 'XXRCM_CLNT_GRP_CAL_ASSN');


*****DONE*****                        
CREATE OR REPLACE VIEW rcm_app.xxrcm_value_map_def_vw (map_definition_id, map_code, map_desc, active_date_flag, n_value1_sequence, n_value1_prompt_text, n_value1_required_flag, n_value1_column_width, c_value1_sequence, c_value1_prompt_text, c_value1_required_flag, c_value1_column_width, d_value1_sequence, d_value1_prompt_text, d_value1_required_flag, d_value1_column_width, n_value2_sequence, n_value2_prompt_text, n_value2_required_flag, n_value2_column_width, c_value2_sequence, c_value2_prompt_text, c_value2_required_flag, c_value2_column_width, d_value2_sequence, d_value2_prompt_text, d_value2_required_flag, d_value2_column_width, n_value3_sequence, n_value3_prompt_text, n_value3_required_flag, n_value3_column_width, c_value3_sequence, c_value3_prompt_text, c_value3_required_flag, c_value3_column_width, d_value3_sequence, d_value3_prompt_text, d_value3_required_flag, d_value3_column_width, n_value4_sequence, n_value4_prompt_text, n_value4_required_flag, n_value4_column_width, c_value4_sequence, c_value4_prompt_text, c_value4_required_flag, c_value4_column_width, d_value4_sequence, d_value4_prompt_text, d_value4_required_flag, d_value4_column_width, n_value5_sequence, n_value5_prompt_text, n_value5_required_flag, n_value5_column_width, c_value5_sequence, c_value5_prompt_text, c_value5_required_flag, c_value5_column_width, d_value5_sequence, d_value5_prompt_text, d_value5_required_flag, d_value5_column_width, n_value6_sequence, n_value6_prompt_text, n_value6_required_flag, n_value6_column_width, c_value6_sequence, c_value6_prompt_text, c_value6_required_flag, c_value6_column_width, d_value6_sequence, d_value6_prompt_text, d_value6_required_flag, d_value6_column_width, n_value7_sequence, n_value7_prompt_text, n_value7_required_flag, n_value7_column_width, c_value7_sequence, c_value7_prompt_text, c_value7_required_flag, c_value7_column_width, d_value7_sequence, d_value7_prompt_text, d_value7_required_flag, d_value7_column_width, n_value8_sequence, n_value8_prompt_text, n_value8_required_flag, n_value8_column_width, c_value8_sequence, c_value8_prompt_text, c_value8_required_flag, c_value8_column_width, d_value8_sequence, d_value8_prompt_text, d_value8_required_flag, d_value8_column_width, n_value9_sequence, n_value9_prompt_text, n_value9_required_flag, n_value9_column_width, c_value9_sequence, c_value9_prompt_text, c_value9_required_flag, c_value9_column_width, d_value9_sequence, d_value9_prompt_text, d_value9_required_flag, d_value9_column_width, n_value10_sequence, n_value10_prompt_text, n_value10_required_flag, n_value10_column_width, c_value10_sequence, c_value10_prompt_text, c_value10_required_flag, c_value10_column_width, d_value10_sequence, d_value10_prompt_text, d_value10_required_flag, d_value10_column_width, n_value11_sequence, n_value11_prompt_text, n_value11_required_flag, n_value11_column_width, c_value11_sequence, c_value11_prompt_text, c_value11_required_flag, c_value11_column_width, d_value11_sequence, d_value11_prompt_text, d_value11_required_flag, d_value11_column_width, n_value12_sequence, n_value12_prompt_text, n_value12_required_flag, n_value12_column_width, c_value12_sequence, c_value12_prompt_text, c_value12_required_flag, c_value12_column_width, d_value12_sequence, d_value12_prompt_text, d_value12_required_flag, d_value12_column_width, n_value13_sequence, n_value13_prompt_text, n_value13_required_flag, n_value13_column_width, c_value13_sequence, c_value13_prompt_text, c_value13_required_flag, c_value13_column_width, d_value13_sequence, d_value13_prompt_text, d_value13_required_flag, d_value13_column_width, n_value14_sequence, n_value14_prompt_text, n_value14_required_flag, n_value14_column_width, c_value14_sequence, c_value14_prompt_text, c_value14_required_flag, c_value14_column_width, d_value14_sequence, d_value14_prompt_text, d_value14_required_flag, d_value14_column_width, n_value15_sequence, n_value15_prompt_text, n_value15_required_flag, n_value15_column_width, c_value15_sequence, c_value15_prompt_text, c_value15_required_flag, c_value15_column_width, d_value15_sequence, d_value15_prompt_text, d_value15_required_flag, d_value15_column_width, n_value16_sequence, n_value16_prompt_text, n_value16_required_flag, n_value16_column_width, c_value16_sequence, c_value16_prompt_text, c_value16_required_flag, c_value16_column_width, d_value16_sequence, d_value16_prompt_text, d_value16_required_flag, d_value16_column_width, n_value17_sequence, n_value17_prompt_text, n_value17_required_flag, n_value17_column_width, c_value17_sequence, c_value17_prompt_text, c_value17_required_flag, c_value17_column_width, d_value17_sequence, d_value17_prompt_text, d_value17_required_flag, d_value17_column_width, n_value18_sequence, n_value18_prompt_text, n_value18_required_flag, n_value18_column_width, c_value18_sequence, c_value18_prompt_text, c_value18_required_flag, c_value18_column_width, d_value18_sequence, d_value18_prompt_text, d_value18_required_flag, d_value18_column_width, n_value19_sequence, n_value19_prompt_text, n_value19_required_flag, n_value19_column_width, c_value19_sequence, c_value19_prompt_text, c_value19_required_flag, c_value19_column_width, d_value19_sequence, d_value19_prompt_text, d_value19_required_flag, d_value19_column_width, n_value20_sequence, n_value20_prompt_text, n_value20_required_flag, n_value20_column_width, c_value20_sequence, c_value20_prompt_text, c_value20_required_flag, c_value20_column_width, d_value20_sequence, d_value20_prompt_text, d_value20_required_flag, d_value20_column_width, n_value1_column_name, c_value1_column_name, d_value1_column_name, n_value2_column_name, c_value2_column_name, d_value2_column_name, n_value3_column_name, c_value3_column_name, d_value3_column_name, n_value4_column_name, c_value4_column_name, d_value4_column_name, n_value5_column_name, c_value5_column_name, d_value5_column_name, n_value6_column_name, c_value6_column_name, d_value6_column_name, n_value7_column_name, c_value7_column_name, d_value7_column_name, n_value8_column_name, c_value8_column_name, d_value8_column_name, n_value9_column_name, c_value9_column_name, d_value9_column_name, n_value10_column_name, c_value10_column_name, d_value10_column_name, n_value11_column_name, c_value11_column_name, d_value11_column_name, n_value12_column_name, c_value12_column_name, d_value12_column_name, n_value13_column_name, c_value13_column_name, d_value13_column_name, n_value14_column_name, c_value14_column_name, d_value14_column_name, n_value15_column_name, c_value15_column_name, d_value15_column_name, n_value16_column_name, c_value16_column_name, d_value16_column_name, n_value17_column_name, c_value17_column_name, d_value17_column_name, n_value18_column_name, c_value18_column_name, d_value18_column_name, n_value19_column_name, c_value19_column_name, d_value19_column_name, n_value20_column_name, c_value20_column_name, d_value20_column_name, attribute1, attribute2, attribute3, attribute4, attribute5, active_begin_date, active_end_date, created_by, creation_date, last_updated_by, last_update_date, n_value1_ui_show, n_value1_ui_update, c_value1_ui_show, c_value1_ui_update, d_value1_ui_show, d_value1_ui_update, n_value2_ui_show, n_value2_ui_update, c_value2_ui_show, c_value2_ui_update, d_value2_ui_show, d_value2_ui_update, n_value3_ui_show, n_value3_ui_update, c_value3_ui_show, c_value3_ui_update, d_value3_ui_show, d_value3_ui_update, n_value4_ui_show, n_value4_ui_update, c_value4_ui_show, c_value4_ui_update, d_value4_ui_show, d_value4_ui_update, n_value5_ui_show, n_value5_ui_update, c_value5_ui_show, c_value5_ui_update, d_value5_ui_show, d_value5_ui_update, n_value6_ui_show, n_value6_ui_update, c_value6_ui_show, c_value6_ui_update, d_value6_ui_show, d_value6_ui_update, n_value7_ui_show, n_value7_ui_update, c_value7_ui_show, c_value7_ui_update, d_value7_ui_show, d_value7_ui_update, n_value8_ui_show, n_value8_ui_update, c_value8_ui_show, c_value8_ui_update, d_value8_ui_show, d_value8_ui_update, n_value9_ui_show, n_value9_ui_update, c_value9_ui_show, c_value9_ui_update, d_value9_ui_show, d_value9_ui_update, n_value10_ui_show, n_value10_ui_update, c_value10_ui_show, c_value10_ui_update, d_value10_ui_show, d_value10_ui_update, n_value11_ui_show, n_value11_ui_update, c_value11_ui_show, c_value11_ui_update, d_value11_ui_show, d_value11_ui_update, n_value12_ui_show, n_value12_ui_update, c_value12_ui_show, c_value12_ui_update, d_value12_ui_show, d_value12_ui_update, n_value13_ui_show, n_value13_ui_update, c_value13_ui_show, c_value13_ui_update, d_value13_ui_show, d_value13_ui_update, n_value14_ui_show, n_value14_ui_update, c_value14_ui_show, c_value14_ui_update, d_value14_ui_show, d_value14_ui_update, n_value15_ui_show, n_value15_ui_update, c_value15_ui_show, c_value15_ui_update, d_value15_ui_show, d_value15_ui_update, n_value16_ui_show, n_value16_ui_update, c_value16_ui_show, c_value16_ui_update, d_value16_ui_show, d_value16_ui_update, n_value17_ui_show, n_value17_ui_update, c_value17_ui_show, c_value17_ui_update, d_value17_ui_show, d_value17_ui_update, n_value18_ui_show, n_value18_ui_update, c_value18_ui_show, c_value18_ui_update, d_value18_ui_show, d_value18_ui_update, n_value19_ui_show, n_value19_ui_update, c_value19_ui_show, c_value19_ui_update, d_value19_ui_show, d_value19_ui_update, n_value20_ui_show, n_value20_ui_update, c_value20_ui_show, c_value20_ui_update, d_value20_ui_show, d_value20_ui_update) AS ( SELECT
    map_definition_id,
    map_code,
    map_desc,
    active_date_flag,
    n_value1_sequence,
    n_value1_prompt_text,
    n_value1_required_flag,
    n_value1_column_width,
    c_value1_sequence,
    c_value1_prompt_text,
    c_value1_required_flag,
    c_value1_column_width,
    d_value1_sequence,
    d_value1_prompt_text,
    d_value1_required_flag,
    d_value1_column_width,
    n_value2_sequence,
    n_value2_prompt_text,
    n_value2_required_flag,
    n_value2_column_width,
    c_value2_sequence,
    c_value2_prompt_text,
    c_value2_required_flag,
    c_value2_column_width,
    d_value2_sequence,
    d_value2_prompt_text,
    d_value2_required_flag,
    d_value2_column_width,
    n_value3_sequence,
    n_value3_prompt_text,
    n_value3_required_flag,
    n_value3_column_width,
    c_value3_sequence,
    c_value3_prompt_text,
    c_value3_required_flag,
    c_value3_column_width,
    d_value3_sequence,
    d_value3_prompt_text,
    d_value3_required_flag,
    d_value3_column_width,
    n_value4_sequence,
    n_value4_prompt_text,
    n_value4_required_flag,
    n_value4_column_width,
    c_value4_sequence,
    c_value4_prompt_text,
    c_value4_required_flag,
    c_value4_column_width,
    d_value4_sequence,
    d_value4_prompt_text,
    d_value4_required_flag,
    d_value4_column_width,
    n_value5_sequence,
    n_value5_prompt_text,
    n_value5_required_flag,
    n_value5_column_width,
    c_value5_sequence,
    c_value5_prompt_text,
    c_value5_required_flag,
    c_value5_column_width,
    d_value5_sequence,
    d_value5_prompt_text,
    d_value5_required_flag,
    d_value5_column_width,
    n_value6_sequence,
    n_value6_prompt_text,
    n_value6_required_flag,
    n_value6_column_width,
    c_value6_sequence,
    c_value6_prompt_text,
    c_value6_required_flag,
    c_value6_column_width,
    d_value6_sequence,
    d_value6_prompt_text,
    d_value6_required_flag,
    d_value6_column_width,
    n_value7_sequence,
    n_value7_prompt_text,
    n_value7_required_flag,
    n_value7_column_width,
    c_value7_sequence,
    c_value7_prompt_text,
    c_value7_required_flag,
    c_value7_column_width,
    d_value7_sequence,
    d_value7_prompt_text,
    d_value7_required_flag,
    d_value7_column_width,
    n_value8_sequence,
    n_value8_prompt_text,
    n_value8_required_flag,
    n_value8_column_width,
    c_value8_sequence,
    c_value8_prompt_text,
    c_value8_required_flag,
    c_value8_column_width,
    d_value8_sequence,
    d_value8_prompt_text,
    d_value8_required_flag,
    d_value8_column_width,
    n_value9_sequence,
    n_value9_prompt_text,
    n_value9_required_flag,
    n_value9_column_width,
    c_value9_sequence,
    c_value9_prompt_text,
    c_value9_required_flag,
    c_value9_column_width,
    d_value9_sequence,
    d_value9_prompt_text,
    d_value9_required_flag,
    d_value9_column_width,
    n_value10_sequence,
    n_value10_prompt_text,
    n_value10_required_flag,
    n_value10_column_width,
    c_value10_sequence,
    c_value10_prompt_text,
    c_value10_required_flag,
    c_value10_column_width,
    d_value10_sequence,
    d_value10_prompt_text,
    d_value10_required_flag,
    d_value10_column_width,
    n_value11_sequence,
    n_value11_prompt_text,
    n_value11_required_flag,
    n_value11_column_width,
    c_value11_sequence,
    c_value11_prompt_text,
    c_value11_required_flag,
    c_value11_column_width,
    d_value11_sequence,
    d_value11_prompt_text,
    d_value11_required_flag,
    d_value11_column_width,
    n_value12_sequence,
    n_value12_prompt_text,
    n_value12_required_flag,
    n_value12_column_width,
    c_value12_sequence,
    c_value12_prompt_text,
    c_value12_required_flag,
    c_value12_column_width,
    d_value12_sequence,
    d_value12_prompt_text,
    d_value12_required_flag,
    d_value12_column_width,
    n_value13_sequence,
    n_value13_prompt_text,
    n_value13_required_flag,
    n_value13_column_width,
    c_value13_sequence,
    c_value13_prompt_text,
    c_value13_required_flag,
    c_value13_column_width,
    d_value13_sequence,
    d_value13_prompt_text,
    d_value13_required_flag,
    d_value13_column_width,
    n_value14_sequence,
    n_value14_prompt_text,
    n_value14_required_flag,
    n_value14_column_width,
    c_value14_sequence,
    c_value14_prompt_text,
    c_value14_required_flag,
    c_value14_column_width,
    d_value14_sequence,
    d_value14_prompt_text,
    d_value14_required_flag,
    d_value14_column_width,
    n_value15_sequence,
    n_value15_prompt_text,
    n_value15_required_flag,
    n_value15_column_width,
    c_value15_sequence,
    c_value15_prompt_text,
    c_value15_required_flag,
    c_value15_column_width,
    d_value15_sequence,
    d_value15_prompt_text,
    d_value15_required_flag,
    d_value15_column_width,
    n_value16_sequence,
    n_value16_prompt_text,
    n_value16_required_flag,
    n_value16_column_width,
    c_value16_sequence,
    c_value16_prompt_text,
    c_value16_required_flag,
    c_value16_column_width,
    d_value16_sequence,
    d_value16_prompt_text,
    d_value16_required_flag,
    d_value16_column_width,
    n_value17_sequence,
    n_value17_prompt_text,
    n_value17_required_flag,
    n_value17_column_width,
    c_value17_sequence,
    c_value17_prompt_text,
    c_value17_required_flag,
    c_value17_column_width,
    d_value17_sequence,
    d_value17_prompt_text,
    d_value17_required_flag,
    d_value17_column_width,
    n_value18_sequence,
    n_value18_prompt_text,
    n_value18_required_flag,
    n_value18_column_width,
    c_value18_sequence,
    c_value18_prompt_text,
    c_value18_required_flag,
    c_value18_column_width,
    d_value18_sequence,
    d_value18_prompt_text,
    d_value18_required_flag,
    d_value18_column_width,
    n_value19_sequence,
    n_value19_prompt_text,
    n_value19_required_flag,
    n_value19_column_width,
    c_value19_sequence,
    c_value19_prompt_text,
    c_value19_required_flag,
    c_value19_column_width,
    d_value19_sequence,
    d_value19_prompt_text,
    d_value19_required_flag,
    d_value19_column_width,
    n_value20_sequence,
    n_value20_prompt_text,
    n_value20_required_flag,
    n_value20_column_width,
    c_value20_sequence,
    c_value20_prompt_text,
    c_value20_required_flag,
    c_value20_column_width,
    d_value20_sequence,
    d_value20_prompt_text,
    d_value20_required_flag,
    d_value20_column_width,
    'N_VALUE1' n_value1_column_name,
    'C_VALUE1' c_value1_column_name,
    'D_VALUE1' d_value1_column_name,
    'N_VALUE2' n_value2_column_name,
    'C_VALUE2' c_value2_column_name,
    'D_VALUE2' d_value2_column_name,
    'N_VALUE3' n_value3_column_name,
    'C_VALUE3' c_value3_column_name,
    'D_VALUE3' d_value3_column_name,
    'N_VALUE4' n_value4_column_name,
    'C_VALUE4' c_value4_column_name,
    'D_VALUE4' d_value4_column_name,
    'N_VALUE5' n_value5_column_name,
    'C_VALUE5' c_value5_column_name,
    'D_VALUE5' d_value5_column_name,
    'N_VALUE6' n_value6_column_name,
    'C_VALUE6' c_value6_column_name,
    'D_VALUE6' d_value6_column_name,
    'N_VALUE7' n_value7_column_name,
    'C_VALUE7' c_value7_column_name,
    'D_VALUE7' d_value7_column_name,
    'N_VALUE8' n_value8_column_name,
    'C_VALUE8' c_value8_column_name,
    'D_VALUE8' d_value8_column_name,
    'N_VALUE9' n_value9_column_name,
    'C_VALUE9' c_value9_column_name,
    'D_VALUE9' d_value9_column_name,
    'N_VALUE10' n_value10_column_name,
    'C_VALUE10' c_value10_column_name,
    'D_VALUE10' d_value10_column_name,
    'N_VALUE11' n_value11_column_name,
    'C_VALUE11' c_value11_column_name,
    'D_VALUE11' d_value11_column_name,
    'N_VALUE12' n_value12_column_name,
    'C_VALUE12' c_value12_column_name,
    'D_VALUE12' d_value12_column_name,
    'N_VALUE13' n_value13_column_name,
    'C_VALUE13' c_value13_column_name,
    'D_VALUE13' d_value13_column_name,
    'N_VALUE14' n_value14_column_name,
    'C_VALUE14' c_value14_column_name,
    'D_VALUE14' d_value14_column_name,
    'N_VALUE15' n_value15_column_name,
    'C_VALUE15' c_value15_column_name,
    'D_VALUE15' d_value15_column_name,
    'N_VALUE16' n_value16_column_name,
    'C_VALUE16' c_value16_column_name,
    'D_VALUE16' d_value16_column_name,
    'N_VALUE17' n_value17_column_name,
    'C_VALUE17' c_value17_column_name,
    'D_VALUE17' d_value17_column_name,
    'N_VALUE18' n_value18_column_name,
    'C_VALUE18' c_value18_column_name,
    'D_VALUE18' d_value18_column_name,
    'N_VALUE19' n_value19_column_name,
    'C_VALUE19' c_value19_column_name,
    'D_VALUE19' d_value19_column_name,
    'N_VALUE20' n_value20_column_name,
    'C_VALUE20' c_value20_column_name,
    'D_VALUE20' d_value20_column_name,
    attribute1,
    attribute2,
    attribute3,
    attribute4,
    attribute5,
    active_begin_date,
    active_end_date,
    created_by,
    creation_date,
    last_updated_by,
    last_update_date,
    n_value1_ui_show,
    n_value1_ui_update,
    c_value1_ui_show,
    c_value1_ui_update,
    d_value1_ui_show,
    d_value1_ui_update,
    n_value2_ui_show,
    n_value2_ui_update,
    c_value2_ui_show,
    c_value2_ui_update,
    d_value2_ui_show,
    d_value2_ui_update,
    n_value3_ui_show,
    n_value3_ui_update,
    c_value3_ui_show,
    c_value3_ui_update,
    d_value3_ui_show,
    d_value3_ui_update,
    n_value4_ui_show,
    n_value4_ui_update,
    c_value4_ui_show,
    c_value4_ui_update,
    d_value4_ui_show,
    d_value4_ui_update,
    n_value5_ui_show,
    n_value5_ui_update,
    c_value5_ui_show,
    c_value5_ui_update,
    d_value5_ui_show,
    d_value5_ui_update,
    n_value6_ui_show,
    n_value6_ui_update,
    c_value6_ui_show,
    c_value6_ui_update,
    d_value6_ui_show,
    d_value6_ui_update,
    n_value7_ui_show,
    n_value7_ui_update,
    c_value7_ui_show,
    c_value7_ui_update,
    d_value7_ui_show,
    d_value7_ui_update,
    n_value8_ui_show,
    n_value8_ui_update,
    c_value8_ui_show,
    c_value8_ui_update,
    d_value8_ui_show,
    d_value8_ui_update,
    n_value9_ui_show,
    n_value9_ui_update,
    c_value9_ui_show,
    c_value9_ui_update,
    d_value9_ui_show,
    d_value9_ui_update,
    n_value10_ui_show,
    n_value10_ui_update,
    c_value10_ui_show,
    c_value10_ui_update,
    d_value10_ui_show,
    d_value10_ui_update,
    n_value11_ui_show,
    n_value11_ui_update,
    c_value11_ui_show,
    c_value11_ui_update,
    d_value11_ui_show,
    d_value11_ui_update,
    n_value12_ui_show,
    n_value12_ui_update,
    c_value12_ui_show,
    c_value12_ui_update,
    d_value12_ui_show,
    d_value12_ui_update,
    n_value13_ui_show,
    n_value13_ui_update,
    c_value13_ui_show,
    c_value13_ui_update,
    d_value13_ui_show,
    d_value13_ui_update,
    n_value14_ui_show,
    n_value14_ui_update,
    c_value14_ui_show,
    c_value14_ui_update,
    d_value14_ui_show,
    d_value14_ui_update,
    n_value15_ui_show,
    n_value15_ui_update,
    c_value15_ui_show,
    c_value15_ui_update,
    d_value15_ui_show,
    d_value15_ui_update,
    n_value16_ui_show,
    n_value16_ui_update,
    c_value16_ui_show,
    c_value16_ui_update,
    d_value16_ui_show,
    d_value16_ui_update,
    n_value17_ui_show,
    n_value17_ui_update,
    c_value17_ui_show,
    c_value17_ui_update,
    d_value17_ui_show,
    d_value17_ui_update,
    n_value18_ui_show,
    n_value18_ui_update,
    c_value18_ui_show,
    c_value18_ui_update,
    d_value18_ui_show,
    d_value18_ui_update,
    n_value19_ui_show,
    n_value19_ui_update,
    c_value19_ui_show,
    c_value19_ui_update,
    d_value19_ui_show,
    d_value19_ui_update,
    n_value20_ui_show,
    n_value20_ui_update,
    c_value20_ui_show,
    c_value20_ui_update,
    d_value20_ui_show,
    d_value20_ui_update
FROM
    rcm_cmn.xxrcm_value_map_def
);

*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_value_map_def_data_vw (map_definition_id, map_code, map_desc, active_date_flag, map_id, def_active_begin_date, def_active_end_date, n_value1_prompt_text, c_value1_prompt_text, d_value1_prompt_text, n_value1, c_value1, d_value1, n_value2_prompt_text, c_value2_prompt_text, d_value2_prompt_text, n_value2, c_value2, d_value2, n_value3_prompt_text, c_value3_prompt_text, d_value3_prompt_text, n_value3, c_value3, d_value3, n_value4_prompt_text, c_value4_prompt_text, d_value4_prompt_text, n_value4, c_value4, d_value4, n_value5_prompt_text, c_value5_prompt_text, d_value5_prompt_text, n_value5, c_value5, d_value5, n_value6_prompt_text, c_value6_prompt_text, d_value6_prompt_text, n_value6, c_value6, d_value6, n_value7_prompt_text, c_value7_prompt_text, d_value7_prompt_text, n_value7, c_value7, d_value7, n_value8_prompt_text, c_value8_prompt_text, d_value8_prompt_text, n_value8, c_value8, d_value8, n_value9_prompt_text, c_value9_prompt_text, d_value9_prompt_text, n_value9, c_value9, d_value9, n_value10_prompt_text, c_value10_prompt_text, d_value10_prompt_text, n_value10, c_value10, d_value10, n_value11_prompt_text, c_value11_prompt_text, d_value11_prompt_text, n_value11, c_value11, d_value11, n_value12_prompt_text, c_value12_prompt_text, d_value12_prompt_text, n_value12, c_value12, d_value12, n_value13_prompt_text, c_value13_prompt_text, d_value13_prompt_text, n_value13, c_value13, d_value13, n_value14_prompt_text, c_value14_prompt_text, d_value14_prompt_text, n_value14, c_value14, d_value14, n_value15_prompt_text, c_value15_prompt_text, d_value15_prompt_text, n_value15, c_value15, d_value15, n_value16_prompt_text, c_value16_prompt_text, d_value16_prompt_text, n_value16, c_value16, d_value16, n_value17_prompt_text, c_value17_prompt_text, d_value17_prompt_text, n_value17, c_value17, d_value17, n_value18_prompt_text, c_value18_prompt_text, d_value18_prompt_text, n_value18, c_value18, d_value18, n_value19_prompt_text, c_value19_prompt_text, d_value19_prompt_text, n_value19, c_value19, d_value19, n_value20_prompt_text, c_value20_prompt_text, d_value20_prompt_text, n_value20, c_value20, d_value20, n_value1_column_name, c_value1_column_name, d_value1_column_name, n_value2_column_name, c_value2_column_name, d_value2_column_name, n_value3_column_name, c_value3_column_name, d_value3_column_name, n_value4_column_name, c_value4_column_name, d_value4_column_name, n_value5_column_name, c_value5_column_name, d_value5_column_name, n_value6_column_name, c_value6_column_name, d_value6_column_name, n_value7_column_name, c_value7_column_name, d_value7_column_name, n_value8_column_name, c_value8_column_name, d_value8_column_name, n_value9_column_name, c_value9_column_name, d_value9_column_name, n_value10_column_name, c_value10_column_name, d_value10_column_name, n_value11_column_name, c_value11_column_name, d_value11_column_name, n_value12_column_name, c_value12_column_name, d_value12_column_name, n_value13_column_name, c_value13_column_name, d_value13_column_name, n_value14_column_name, c_value14_column_name, d_value14_column_name, n_value15_column_name, c_value15_column_name, d_value15_column_name, n_value16_column_name, c_value16_column_name, d_value16_column_name, n_value17_column_name, c_value17_column_name, d_value17_column_name, n_value18_column_name, c_value18_column_name, d_value18_column_name, n_value19_column_name, c_value19_column_name, d_value19_column_name, n_value20_column_name, c_value20_column_name, d_value20_column_name, data_active_begin_date, data_active_end_date, created_by, creation_date, last_updated_by, last_update_date, last_update_login, n_value1_ui_show, n_value1_ui_update, c_value1_ui_show, c_value1_ui_update, d_value1_ui_show, d_value1_ui_update, n_value2_ui_show, n_value2_ui_update, c_value2_ui_show, c_value2_ui_update, d_value2_ui_show, d_value2_ui_update, n_value3_ui_show, n_value3_ui_update, c_value3_ui_show, c_value3_ui_update, d_value3_ui_show, d_value3_ui_update, n_value4_ui_show, n_value4_ui_update, c_value4_ui_show, c_value4_ui_update, d_value4_ui_show, d_value4_ui_update, n_value5_ui_show, n_value5_ui_update, c_value5_ui_show, c_value5_ui_update, d_value5_ui_show, d_value5_ui_update, n_value6_ui_show, n_value6_ui_update, c_value6_ui_show, c_value6_ui_update, d_value6_ui_show, d_value6_ui_update, n_value7_ui_show, n_value7_ui_update, c_value7_ui_show, c_value7_ui_update, d_value7_ui_show, d_value7_ui_update, n_value8_ui_show, n_value8_ui_update, c_value8_ui_show, c_value8_ui_update, d_value8_ui_show, d_value8_ui_update, n_value9_ui_show, n_value9_ui_update, c_value9_ui_show, c_value9_ui_update, d_value9_ui_show, d_value9_ui_update, n_value10_ui_show, n_value10_ui_update, c_value10_ui_show, c_value10_ui_update, d_value10_ui_show, d_value10_ui_update, n_value11_ui_show, n_value11_ui_update, c_value11_ui_show, c_value11_ui_update, d_value11_ui_show, d_value11_ui_update, n_value12_ui_show, n_value12_ui_update, c_value12_ui_show, c_value12_ui_update, d_value12_ui_show, d_value12_ui_update, n_value13_ui_show, n_value13_ui_update, c_value13_ui_show, c_value13_ui_update, d_value13_ui_show, d_value13_ui_update, n_value14_ui_show, n_value14_ui_update, c_value14_ui_show, c_value14_ui_update, d_value14_ui_show, d_value14_ui_update, n_value15_ui_show, n_value15_ui_update, c_value15_ui_show, c_value15_ui_update, d_value15_ui_show, d_value15_ui_update, n_value16_ui_show, n_value16_ui_update, c_value16_ui_show, c_value16_ui_update, d_value16_ui_show, d_value16_ui_update, n_value17_ui_show, n_value17_ui_update, c_value17_ui_show, c_value17_ui_update, d_value17_ui_show, d_value17_ui_update, n_value18_ui_show, n_value18_ui_update, c_value18_ui_show, c_value18_ui_update, d_value18_ui_show, d_value18_ui_update, n_value19_ui_show, n_value19_ui_update, c_value19_ui_show, c_value19_ui_update, d_value19_ui_show, d_value19_ui_update, n_value20_ui_show, n_value20_ui_update, c_value20_ui_show, c_value20_ui_update, d_value20_ui_show, d_value20_ui_update, n_value1_sequence, c_value1_sequence, d_value1_sequence, n_value2_sequence, c_value2_sequence, d_value2_sequence, n_value3_sequence, c_value3_sequence, d_value3_sequence, n_value4_sequence, c_value4_sequence, d_value4_sequence, n_value5_sequence, c_value5_sequence, d_value5_sequence, n_value6_sequence, c_value6_sequence, d_value6_sequence, n_value7_sequence, c_value7_sequence, d_value7_sequence, n_value8_sequence, c_value8_sequence, d_value8_sequence, n_value9_sequence, c_value9_sequence, d_value9_sequence, n_value10_sequence, c_value10_sequence, d_value10_sequence, n_value11_sequence, c_value11_sequence, d_value11_sequence, n_value12_sequence, c_value12_sequence, d_value12_sequence, n_value13_sequence, c_value13_sequence, d_value13_sequence, n_value14_sequence, c_value14_sequence, d_value14_sequence, n_value15_sequence, c_value15_sequence, d_value15_sequence, n_value16_sequence, c_value16_sequence, d_value16_sequence, n_value17_sequence, c_value17_sequence, d_value17_sequence, n_value18_sequence, c_value18_sequence, d_value18_sequence, n_value19_sequence, c_value19_sequence, d_value19_sequence, n_value20_sequence, c_value20_sequence, d_value20_sequence) AS ( SELECT
    xvmd.map_definition_id,
    xvmd.map_code,
    xvmd.map_desc,
    xvmd.active_date_flag,
    xvm.map_id
      /*,xvmd.n_value1_sequence
  ,xvmd.n_value1_prompt_text
  ,xvmd.n_value1_required_flag
  ,xvmd.n_value1_column_width
  ,xvmd.c_value1_sequence
  ,xvmd.c_value1_prompt_text
  ,xvmd.c_value1_required_flag
  ,xvmd.c_value1_column_width
  ,xvmd.d_value1_sequence
  ,xvmd.d_value1_prompt_text
  ,xvmd.d_value1_required_flag
  ,xvmd.d_value1_column_width
  ,xvmd.n_value2_sequence
  ,xvmd.n_value2_prompt_text
  ,xvmd.n_value2_required_flag
  ,xvmd.n_value2_column_width
  ,xvmd.c_value2_sequence
  ,xvmd.c_value2_prompt_text
  ,xvmd.c_value2_required_flag
  ,xvmd.c_value2_column_width
  ,xvmd.d_value2_sequence
  ,xvmd.d_value2_prompt_text
  ,xvmd.d_value2_required_flag
  ,xvmd.d_value2_column_width
  ,xvmd.n_value3_sequence
  ,xvmd.n_value3_prompt_text
  ,xvmd.n_value3_required_flag
  ,xvmd.n_value3_column_width
  ,xvmd.c_value3_sequence
  ,xvmd.c_value3_prompt_text
  ,xvmd.c_value3_required_flag
  ,xvmd.c_value3_column_width
  ,xvmd.d_value3_sequence
  ,xvmd.d_value3_prompt_text
  ,xvmd.d_value3_required_flag
  ,xvmd.d_value3_column_width
  ,xvmd.n_value4_sequence
  ,xvmd.n_value4_prompt_text
  ,xvmd.n_value4_required_flag
  ,xvmd.n_value4_column_width
  ,xvmd.c_value4_sequence
  ,xvmd.c_value4_prompt_text
  ,xvmd.c_value4_required_flag
  ,xvmd.c_value4_column_width
  ,xvmd.d_value4_sequence
  ,xvmd.d_value4_prompt_text
  ,xvmd.d_value4_required_flag
  ,xvmd.d_value4_column_width
  ,xvmd.n_value5_sequence
  ,xvmd.n_value5_prompt_text
  ,xvmd.n_value5_required_flag
  ,xvmd.n_value5_column_width
  ,xvmd.c_value5_sequence
  ,xvmd.c_value5_prompt_text
  ,xvmd.c_value5_required_flag
  ,xvmd.c_value5_column_width
  ,xvmd.d_value5_sequence
  ,xvmd.d_value5_prompt_text
  ,xvmd.d_value5_required_flag
  ,xvmd.d_value5_column_width
  ,xvmd.n_value6_sequence
  ,xvmd.n_value6_prompt_text
  ,xvmd.n_value6_required_flag
  ,xvmd.n_value6_column_width
  ,xvmd.c_value6_sequence
  ,xvmd.c_value6_prompt_text
  ,xvmd.c_value6_required_flag
  ,xvmd.c_value6_column_width
  ,xvmd.d_value6_sequence
  ,xvmd.d_value6_prompt_text
  ,xvmd.d_value6_required_flag
  ,xvmd.d_value6_column_width
  ,xvmd.n_value7_sequence
  ,xvmd.n_value7_prompt_text
  ,xvmd.n_value7_required_flag
  ,xvmd.n_value7_column_width
  ,xvmd.c_value7_sequence
  ,xvmd.c_value7_prompt_text
  ,xvmd.c_value7_required_flag
  ,xvmd.c_value7_column_width
  ,xvmd.d_value7_sequence
  ,xvmd.d_value7_prompt_text
  ,xvmd.d_value7_required_flag
  ,xvmd.d_value7_column_width
  ,xvmd.n_value8_sequence
  ,xvmd.n_value8_prompt_text
  ,xvmd.n_value8_required_flag
  ,xvmd.n_value8_column_width
  ,xvmd.c_value8_sequence
  ,xvmd.c_value8_prompt_text
  ,xvmd.c_value8_required_flag
  ,xvmd.c_value8_column_width
  ,xvmd.d_value8_sequence
  ,xvmd.d_value8_prompt_text
  ,xvmd.d_value8_required_flag
  ,xvmd.d_value8_column_width
  ,xvmd.n_value9_sequence
  ,xvmd.n_value9_prompt_text
  ,xvmd.n_value9_required_flag
  ,xvmd.n_value9_column_width
  ,xvmd.c_value9_sequence
  ,xvmd.c_value9_prompt_text
  ,xvmd.c_value9_required_flag
  ,xvmd.c_value9_column_width
  ,xvmd.d_value9_sequence
  ,xvmd.d_value9_prompt_text
  ,xvmd.d_value9_required_flag
  ,xvmd.d_value9_column_width
  ,xvmd.n_value10_sequence
  ,xvmd.n_value10_prompt_text
  ,xvmd.n_value10_required_flag
  ,xvmd.n_value10_column_width
  ,xvmd.c_value10_sequence
  ,xvmd.c_value10_prompt_text
  ,xvmd.c_value10_required_flag
  ,xvmd.c_value10_column_width
  ,xvmd.d_value10_sequence
  ,xvmd.d_value10_prompt_text
  ,xvmd.d_value10_required_flag
  ,xvmd.d_value10_column_width
  ,xvmd.n_value11_sequence
  ,xvmd.n_value11_prompt_text
  ,xvmd.n_value11_required_flag
  ,xvmd.n_value11_column_width
  ,xvmd.c_value11_sequence
  ,xvmd.c_value11_prompt_text
  ,xvmd.c_value11_required_flag
  ,xvmd.c_value11_column_width
  ,xvmd.d_value11_sequence
  ,xvmd.d_value11_prompt_text
  ,xvmd.d_value11_required_flag
  ,xvmd.d_value11_column_width
  ,xvmd.n_value12_sequence
  ,xvmd.n_value12_prompt_text
  ,xvmd.n_value12_required_flag
  ,xvmd.n_value12_column_width
  ,xvmd.c_value12_sequence
  ,xvmd.c_value12_prompt_text
  ,xvmd.c_value12_required_flag
  ,xvmd.c_value12_column_width
  ,xvmd.d_value12_sequence
  ,xvmd.d_value12_prompt_text
  ,xvmd.d_value12_required_flag
  ,xvmd.d_value12_column_width
  ,xvmd.n_value13_sequence
  ,xvmd.n_value13_prompt_text
  ,xvmd.n_value13_required_flag
  ,xvmd.n_value13_column_width
  ,xvmd.c_value13_sequence
  ,xvmd.c_value13_prompt_text
  ,xvmd.c_value13_required_flag
  ,xvmd.c_value13_column_width
  ,xvmd.d_value13_sequence
  ,xvmd.d_value13_prompt_text
  ,xvmd.d_value13_required_flag
  ,xvmd.d_value13_column_width
  ,xvmd.n_value14_sequence
  ,xvmd.n_value14_prompt_text
  ,xvmd.n_value14_required_flag
  ,xvmd.n_value14_column_width
  ,xvmd.c_value14_sequence
  ,xvmd.c_value14_prompt_text
  ,xvmd.c_value14_required_flag
  ,xvmd.c_value14_column_width
  ,xvmd.d_value14_sequence
  ,xvmd.d_value14_prompt_text
  ,xvmd.d_value14_required_flag
  ,xvmd.d_value14_column_width
  ,xvmd.n_value15_sequence
  ,xvmd.n_value15_prompt_text
  ,xvmd.n_value15_required_flag
  ,xvmd.n_value15_column_width
  ,xvmd.c_value15_sequence
  ,xvmd.c_value15_prompt_text
  ,xvmd.c_value15_required_flag
  ,xvmd.c_value15_column_width
  ,xvmd.d_value15_sequence
  ,xvmd.d_value15_prompt_text
  ,xvmd.d_value15_required_flag
  ,xvmd.d_value15_column_width
  ,xvmd.n_value16_sequence
  ,xvmd.n_value16_prompt_text
  ,xvmd.n_value16_required_flag
  ,xvmd.n_value16_column_width
  ,xvmd.c_value16_sequence
  ,xvmd.c_value16_prompt_text
  ,xvmd.c_value16_required_flag
  ,xvmd.c_value16_column_width
  ,xvmd.d_value16_sequence
  ,xvmd.d_value16_prompt_text
  ,xvmd.d_value16_required_flag
  ,xvmd.d_value16_column_width
  ,xvmd.n_value17_sequence
  ,xvmd.n_value17_prompt_text
  ,xvmd.n_value17_required_flag
  ,xvmd.n_value17_column_width
  ,xvmd.c_value17_sequence
  ,xvmd.c_value17_prompt_text
  ,xvmd.c_value17_required_flag
  ,xvmd.c_value17_column_width
  ,xvmd.d_value17_sequence
  ,xvmd.d_value17_prompt_text
  ,xvmd.d_value17_required_flag
  ,xvmd.d_value17_column_width
  ,xvmd.n_value18_sequence
  ,xvmd.n_value18_prompt_text
  ,xvmd.n_value18_required_flag
  ,xvmd.n_value18_column_width
  ,xvmd.c_value18_sequence
  ,xvmd.c_value18_prompt_text
  ,xvmd.c_value18_required_flag
  ,xvmd.c_value18_column_width
  ,xvmd.d_value18_sequence
  ,xvmd.d_value18_prompt_text
  ,xvmd.d_value18_required_flag
  ,xvmd.d_value18_column_width
  ,xvmd.n_value19_sequence
  ,xvmd.n_value19_prompt_text
  ,xvmd.n_value19_required_flag
  ,xvmd.n_value19_column_width
  ,xvmd.c_value19_sequence
  ,xvmd.c_value19_prompt_text
  ,xvmd.c_value19_required_flag
  ,xvmd.c_value19_column_width
  ,xvmd.d_value19_sequence
  ,xvmd.d_value19_prompt_text
  ,xvmd.d_value19_required_flag
  ,xvmd.d_value19_column_width
  ,xvmd.n_value20_sequence
  ,xvmd.n_value20_prompt_text
  ,xvmd.n_value20_required_flag
  ,xvmd.n_value20_column_width
  ,xvmd.c_value20_sequence
  ,xvmd.c_value20_prompt_text
  ,xvmd.c_value20_required_flag
  ,xvmd.c_value20_column_width
  ,xvmd.d_value20_sequence
  ,xvmd.d_value20_prompt_text
  ,xvmd.d_value20_required_flag
  ,xvmd.d_value20_column_width
  ,xvmd.attribute1
  ,xvmd.attribute2
  ,xvmd.attribute3
  ,xvmd.attribute4
  ,xvmd.attribute5  */
,
    xvmd.active_begin_date def_active_begin_date,
    xvmd.active_end_date def_active_end_date,
    xvmd.n_value1_prompt_text,
    xvmd.c_value1_prompt_text,
    xvmd.d_value1_prompt_text,
    xvm.n_value1,
    xvm.c_value1,
    xvm.d_value1,
    xvmd.n_value2_prompt_text,
    xvmd.c_value2_prompt_text,
    xvmd.d_value2_prompt_text,
    xvm.n_value2,
    xvm.c_value2,
    xvm.d_value2,
    xvmd.n_value3_prompt_text,
    xvmd.c_value3_prompt_text,
    xvmd.d_value3_prompt_text,
    xvm.n_value3,
    xvm.c_value3,
    xvm.d_value3,
    xvmd.n_value4_prompt_text,
    xvmd.c_value4_prompt_text,
    xvmd.d_value4_prompt_text,
    xvm.n_value4,
    xvm.c_value4,
    xvm.d_value4,
    xvmd.n_value5_prompt_text,
    xvmd.c_value5_prompt_text,
    xvmd.d_value5_prompt_text,
    xvm.n_value5,
    xvm.c_value5,
    xvm.d_value5,
    xvmd.n_value6_prompt_text,
    xvmd.c_value6_prompt_text,
    xvmd.d_value6_prompt_text,
    xvm.n_value6,
    xvm.c_value6,
    xvm.d_value6,
    xvmd.n_value7_prompt_text,
    xvmd.c_value7_prompt_text,
    xvmd.d_value7_prompt_text,
    xvm.n_value7,
    xvm.c_value7,
    xvm.d_value7,
    xvmd.n_value8_prompt_text,
    xvmd.c_value8_prompt_text,
    xvmd.d_value8_prompt_text,
    xvm.n_value8,
    xvm.c_value8,
    xvm.d_value8,
    xvmd.n_value9_prompt_text,
    xvmd.c_value9_prompt_text,
    xvmd.d_value9_prompt_text,
    xvm.n_value9,
    xvm.c_value9,
    xvm.d_value9,
    xvmd.n_value10_prompt_text,
    xvmd.c_value10_prompt_text,
    xvmd.d_value10_prompt_text,
    xvm.n_value10,
    xvm.c_value10,
    xvm.d_value10,
    xvmd.n_value11_prompt_text,
    xvmd.c_value11_prompt_text,
    xvmd.d_value11_prompt_text,
    xvm.n_value11,
    xvm.c_value11,
    xvm.d_value11,
    xvmd.n_value12_prompt_text,
    xvmd.c_value12_prompt_text,
    xvmd.d_value12_prompt_text,
    xvm.n_value12,
    xvm.c_value12,
    xvm.d_value12,
    xvmd.n_value13_prompt_text,
    xvmd.c_value13_prompt_text,
    xvmd.d_value13_prompt_text,
    xvm.n_value13,
    xvm.c_value13,
    xvm.d_value13,
    xvmd.n_value14_prompt_text,
    xvmd.c_value14_prompt_text,
    xvmd.d_value14_prompt_text,
    xvm.n_value14,
    xvm.c_value14,
    xvm.d_value14,
    xvmd.n_value15_prompt_text,
    xvmd.c_value15_prompt_text,
    xvmd.d_value15_prompt_text,
    xvm.n_value15,
    xvm.c_value15,
    xvm.d_value15,
    xvmd.n_value16_prompt_text,
    xvmd.c_value16_prompt_text,
    xvmd.d_value16_prompt_text,
    xvm.n_value16,
    xvm.c_value16,
    xvm.d_value16,
    xvmd.n_value17_prompt_text,
    xvmd.c_value17_prompt_text,
    xvmd.d_value17_prompt_text,
    xvm.n_value17,
    xvm.c_value17,
    xvm.d_value17,
    xvmd.n_value18_prompt_text,
    xvmd.c_value18_prompt_text,
    xvmd.d_value18_prompt_text,
    xvm.n_value18,
    xvm.c_value18,
    xvm.d_value18,
    xvmd.n_value19_prompt_text,
    xvmd.c_value19_prompt_text,
    xvmd.d_value19_prompt_text,
    xvm.n_value19,
    xvm.c_value19,
    xvm.d_value19,
    xvmd.n_value20_prompt_text,
    xvmd.c_value20_prompt_text,
    xvmd.d_value20_prompt_text,
    xvm.n_value20,
    xvm.c_value20,
    xvm.d_value20,
    'N_VALUE1' n_value1_column_name,
    'C_VALUE1' c_value1_column_name,
    'D_VALUE1' d_value1_column_name,
    'N_VALUE2' n_value2_column_name,
    'C_VALUE2' c_value2_column_name,
    'D_VALUE2' d_value2_column_name,
    'N_VALUE3' n_value3_column_name,
    'C_VALUE3' c_value3_column_name,
    'D_VALUE3' d_value3_column_name,
    'N_VALUE4' n_value4_column_name,
    'C_VALUE4' c_value4_column_name,
    'D_VALUE4' d_value4_column_name,
    'N_VALUE5' n_value5_column_name,
    'C_VALUE5' c_value5_column_name,
    'D_VALUE5' d_value5_column_name,
    'N_VALUE6' n_value6_column_name,
    'C_VALUE6' c_value6_column_name,
    'D_VALUE6' d_value6_column_name,
    'N_VALUE7' n_value7_column_name,
    'C_VALUE7' c_value7_column_name,
    'D_VALUE7' d_value7_column_name,
    'N_VALUE8' n_value8_column_name,
    'C_VALUE8' c_value8_column_name,
    'D_VALUE8' d_value8_column_name,
    'N_VALUE9' n_value9_column_name,
    'C_VALUE9' c_value9_column_name,
    'D_VALUE9' d_value9_column_name,
    'N_VALUE10' n_value10_column_name,
    'C_VALUE10' c_value10_column_name,
    'D_VALUE10' d_value10_column_name,
    'N_VALUE11' n_value11_column_name,
    'C_VALUE11' c_value11_column_name,
    'D_VALUE11' d_value11_column_name,
    'N_VALUE12' n_value12_column_name,
    'C_VALUE12' c_value12_column_name,
    'D_VALUE12' d_value12_column_name,
    'N_VALUE13' n_value13_column_name,
    'C_VALUE13' c_value13_column_name,
    'D_VALUE13' d_value13_column_name,
    'N_VALUE14' n_value14_column_name,
    'C_VALUE14' c_value14_column_name,
    'D_VALUE14' d_value14_column_name,
    'N_VALUE15' n_value15_column_name,
    'C_VALUE15' c_value15_column_name,
    'D_VALUE15' d_value15_column_name,
    'N_VALUE16' n_value16_column_name,
    'C_VALUE16' c_value16_column_name,
    'D_VALUE16' d_value16_column_name,
    'N_VALUE17' n_value17_column_name,
    'C_VALUE17' c_value17_column_name,
    'D_VALUE17' d_value17_column_name,
    'N_VALUE18' n_value18_column_name,
    'C_VALUE18' c_value18_column_name,
    'D_VALUE18' d_value18_column_name,
    'N_VALUE19' n_value19_column_name,
    'C_VALUE19' c_value19_column_name,
    'D_VALUE19' d_value19_column_name,
    'N_VALUE20' n_value20_column_name,
    'C_VALUE20' c_value20_column_name,
    'D_VALUE20' d_value20_column_name,
    xvm.active_begin_date data_active_begin_date,
    xvm.active_end_date data_active_end_date,
    xvm.created_by,
    xvm.creation_date,
    xvm.last_updated_by,
    xvm.last_update_date,
    xvm.last_update_login,
    n_value1_ui_show,
    n_value1_ui_update,
    c_value1_ui_show,
    c_value1_ui_update,
    d_value1_ui_show,
    d_value1_ui_update,
    n_value2_ui_show,
    n_value2_ui_update,
    c_value2_ui_show,
    c_value2_ui_update,
    d_value2_ui_show,
    d_value2_ui_update,
    n_value3_ui_show,
    n_value3_ui_update,
    c_value3_ui_show,
    c_value3_ui_update,
    d_value3_ui_show,
    d_value3_ui_update,
    n_value4_ui_show,
    n_value4_ui_update,
    c_value4_ui_show,
    c_value4_ui_update,
    d_value4_ui_show,
    d_value4_ui_update,
    n_value5_ui_show,
    n_value5_ui_update,
    c_value5_ui_show,
    c_value5_ui_update,
    d_value5_ui_show,
    d_value5_ui_update,
    n_value6_ui_show,
    n_value6_ui_update,
    c_value6_ui_show,
    c_value6_ui_update,
    d_value6_ui_show,
    d_value6_ui_update,
    n_value7_ui_show,
    n_value7_ui_update,
    c_value7_ui_show,
    c_value7_ui_update,
    d_value7_ui_show,
    d_value7_ui_update,
    n_value8_ui_show,
    n_value8_ui_update,
    c_value8_ui_show,
    c_value8_ui_update,
    d_value8_ui_show,
    d_value8_ui_update,
    n_value9_ui_show,
    n_value9_ui_update,
    c_value9_ui_show,
    c_value9_ui_update,
    d_value9_ui_show,
    d_value9_ui_update,
    n_value10_ui_show,
    n_value10_ui_update,
    c_value10_ui_show,
    c_value10_ui_update,
    d_value10_ui_show,
    d_value10_ui_update,
    n_value11_ui_show,
    n_value11_ui_update,
    c_value11_ui_show,
    c_value11_ui_update,
    d_value11_ui_show,
    d_value11_ui_update,
    n_value12_ui_show,
    n_value12_ui_update,
    c_value12_ui_show,
    c_value12_ui_update,
    d_value12_ui_show,
    d_value12_ui_update,
    n_value13_ui_show,
    n_value13_ui_update,
    c_value13_ui_show,
    c_value13_ui_update,
    d_value13_ui_show,
    d_value13_ui_update,
    n_value14_ui_show,
    n_value14_ui_update,
    c_value14_ui_show,
    c_value14_ui_update,
    d_value14_ui_show,
    d_value14_ui_update,
    n_value15_ui_show,
    n_value15_ui_update,
    c_value15_ui_show,
    c_value15_ui_update,
    d_value15_ui_show,
    d_value15_ui_update,
    n_value16_ui_show,
    n_value16_ui_update,
    c_value16_ui_show,
    c_value16_ui_update,
    d_value16_ui_show,
    d_value16_ui_update,
    n_value17_ui_show,
    n_value17_ui_update,
    c_value17_ui_show,
    c_value17_ui_update,
    d_value17_ui_show,
    d_value17_ui_update,
    n_value18_ui_show,
    n_value18_ui_update,
    c_value18_ui_show,
    c_value18_ui_update,
    d_value18_ui_show,
    d_value18_ui_update,
    n_value19_ui_show,
    n_value19_ui_update,
    c_value19_ui_show,
    c_value19_ui_update,
    d_value19_ui_show,
    d_value19_ui_update,
    n_value20_ui_show,
    n_value20_ui_update,
    c_value20_ui_show,
    c_value20_ui_update,
    d_value20_ui_show,
    d_value20_ui_update,
    n_value1_sequence,
    c_value1_sequence,
    d_value1_sequence,
    n_value2_sequence,
    c_value2_sequence,
    d_value2_sequence,
    n_value3_sequence,
    c_value3_sequence,
    d_value3_sequence,
    n_value4_sequence,
    c_value4_sequence,
    d_value4_sequence,
    n_value5_sequence,
    c_value5_sequence,
    d_value5_sequence,
    n_value6_sequence,
    c_value6_sequence,
    d_value6_sequence,
    n_value7_sequence,
    c_value7_sequence,
    d_value7_sequence,
    n_value8_sequence,
    c_value8_sequence,
    d_value8_sequence,
    n_value9_sequence,
    c_value9_sequence,
    d_value9_sequence,
    n_value10_sequence,
    c_value10_sequence,
    d_value10_sequence,
    n_value11_sequence,
    c_value11_sequence,
    d_value11_sequence,
    n_value12_sequence,
    c_value12_sequence,
    d_value12_sequence,
    n_value13_sequence,
    c_value13_sequence,
    d_value13_sequence,
    n_value14_sequence,
    c_value14_sequence,
    d_value14_sequence,
    n_value15_sequence,
    c_value15_sequence,
    d_value15_sequence,
    n_value16_sequence,
    c_value16_sequence,
    d_value16_sequence,
    n_value17_sequence,
    c_value17_sequence,
    d_value17_sequence,
    n_value18_sequence,
    c_value18_sequence,
    d_value18_sequence,
    n_value19_sequence,
    c_value19_sequence,
    d_value19_sequence,
    n_value20_sequence,
    c_value20_sequence,
    d_value20_sequence
FROM
    rcm_cmn.xxrcm_value_map_def xvmd,
    rcm_cmn.xxrcm_value_map xvm
WHERE
    xvmd.map_definition_id = xvm.map_definition_id
 );



CREATE OR REPLACE VIEW rcm_app.xxrcm_recall_class_n_v (map_definition_id, map_code, map_desc, value, n_value1_sequence, n_value1_required_flag, n_value1_column_width, fee_name, c_value1_prompt_text, c_value1_sequence, c_value1_required_flag, c_value1_column_width, apply_on, c_value2_prompt_text, c_value2_sequence, c_value2_required_flag, c_value2_column_width, abs_or_percent, c_value3_sequence, c_value3_required_flag, c_value3_column_width, recall_fee_flag, c_value4_prompt_text, c_value4_sequence, c_value4_required_flag, c_value4_column_width, active_date_flag, active_begin_date, active_end_date) AS SELECT
        def.map_definition_id,
        def.map_code,
        def.map_desc,
        val.n_value1 value,
        def.n_value1_sequence,
        def.n_value1_required_flag,
        def.n_value1_column_width,
        val.c_value1 fee_name,
        def.c_value1_prompt_text,
        def.c_value1_sequence,
        def.c_value1_required_flag,
        def.c_value1_column_width,
        val.c_value2 apply_on,
        def.c_value2_prompt_text,
        def.c_value2_sequence,
        def.c_value2_required_flag,
        def.c_value2_column_width,
        val.c_value3 abs_or_percent,
        def.c_value3_sequence,
        def.c_value3_required_flag,
        def.c_value3_column_width,
        val.c_value4 recall_fee_flag,
        def.c_value4_prompt_text,
        def.c_value4_sequence,
        def.c_value4_required_flag,
        def.c_value4_column_width,
        def.active_date_flag,
        def.active_begin_date,
        def.active_end_date
    FROM
        rcm_cmn.xxrcm_value_map_def def,
        rcm_cmn.xxrcm_value_map val
    WHERE
        def.map_code = 'XXRCM_FEE_NAMES'
        AND   def.map_definition_id = val.map_definition_id
        AND   statement_timestamp() BETWEEN def.active_begin_date AND coalesce(def.active_end_date,statement_timestamp() + interval '1 days')
		AND   c_value4 ='N';


*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_vendor_system_profiles2 (reclaim_vendor_id, vendor_id, ap_vendor_number, ap_vendor_name, vendor_type, client, vendor_type_def, fee_id, profile_id, fee_name, apply_on, absolute_or_percent, fee_value, last_update_date, fee_inactive_flag, fee_inactive_status, source, profile_level, fee_start_date, fee_end_date, supplier_type, address, address1, address2, address3, full_address, city, state, zip_code, vendor_start_date, vendor_inactive_date, reclaim_inactive_date, vendor_contact_name, vendor_email, swell_flag, comments, reclaim_last_scan, reclaim_volume_per_week, reclaim_dollars_per_week, reclaim_on_hold, auth_for_debt, apply_max_vend_cost, auth_reason, include_system_profiles) AS (
SELECT
    xvm.reclaim_vendor_id,
    xvm.vendor_id,
    xvm.ap_vendor_number,
    xvm.ap_vendor_name,
    xvm.vendor_type,
    xvm.client,
    CASE
            WHEN xvm.vendor_type = 'I' THEN 'C&S Vendor'
            ELSE 'Customer Vendor'
        END
    vendor_type_def,
    xfd.fee_id,
    xfd.profile_id,
    xfd.fee_name,
    xfd.apply_on,
    xfd.absolute_or_percent,
    xfd.value fee_value,
    xfd.last_update_date,
     --,xfd.pass_through
     --,xfd.pass_through_percent
   
    coalesce(xfd.status,'Active') fee_inactive_flag,
    CASE
            WHEN coalesce(xfd.status,'Active') = 'Active' THEN 'N'
            ELSE 'Y'
        END
    fee_inactive_status,
    xfd.source,
    xfd.profile_level,
    xfd.start_date fee_start_date,
    xfd.end_date fee_end_date,
    xvm.supplier_type,
    xvm.address,
    xvm.address1,
    xvm.address2,
    xvm.address3,
    xvm.address full_address --It is concatenated value
     --|| ' ' || xvm.address1 || ' '|| xvm.address2 || ' '|| xvm.address3
   ,
    xvm.city,
    xvm.state,
    xvm.zip_code,
    xvm.start_date vendor_start_date,
    xvm.inactive_date vendor_inactive_date,
    xvm.reclaim_inactive_date,
    coalesce(xvm.vendor_contact_name_ui,xvm.vendor_contact_name) vendor_contact_name,
    coalesce(xvm.vendor_email_ui,xvm.vendor_email) vendor_email,
    xvm.swell_flag,
    xvm.comments,
    xvm.reclaim_last_scan,
    xvm.reclaim_volume_per_week,
    xvm.reclaim_dollars_per_week,
    xvm.reclaim_on_hold,
    xvm.auth_for_debt,
    xvm.apply_max_vend_cost,
    xvm.auth_reason,
    'N' include_system_profiles
     /*,CASE WHEN NVL( xfd.inactive, 'N' ) = 'N' THEN
                'N'
       ELSE 'Y'
      END include_inactive_fees*/
FROM
    rcm_data.xxrcm_vendor_master xvm,
    rcm_data.xxrcm_fee_details xfd
WHERE
    xfd.reclaim_vendor_id = xvm.reclaim_vendor_id

UNION

SELECT
    NULL reclaim_vendor_id,
    NULL vendor_id,
    NULL ap_vendor_number,
    NULL ap_vendor_name,
    NULL vendor_type,
    NULL client,
    NULL vendor_type_def,
    xfd.fee_id,
    xfd.profile_id,
    xfd.fee_name,
    xfd.apply_on,
    xfd.absolute_or_percent,
    xfd.value fee_value,
    xfd.last_update_date,
    --,xfd.pass_through
    --,xfd.pass_through_percent
    coalesce(xfd.status,'Active') fee_inactive_flag,
    CASE
            WHEN coalesce(xfd.status,'Active') = 'Active' THEN 'N'
            ELSE 'Y'
        END
    fee_inactive_status,
    xfd.source,
    xfd.profile_level,
    xfd.start_date fee_start_date,
    xfd.end_date fee_end_date,
    NULL supplier_type,
    NULL address,
    NULL address1,
    NULL address2,
    NULL address3,
    NULL full_address,
    NULL city,
    NULL state,
    NULL zip_code,
    NULL vendor_start_date,
    NULL vendor_inactive_date,
    NULL reclaim_inactive_date,
    NULL vendor_contact_name,
    NULL vendor_email,
    NULL swell_flag,
    NULL comments,
    NULL reclaim_last_scan,
    NULL reclaim_volume_per_week,
    NULL reclaim_dollars_per_week,
    NULL reclaim_on_hold,
    NULL auth_for_debt,
    NULL apply_max_vend_cost,
    NULL auth_reason,
    'Y' include_system_profiles
      /*,CASE WHEN NVL( xfd.inactive, 'N' ) = 'N' THEN
                'N'
       ELSE 'Y'
      END include_inactive_fees */
FROM
    rcm_data.xxrcm_fee_details xfd
WHERE
    xfd.profile_level = 'SYSTEM'
    AND   reclaim_vendor_id IS NULL
    AND   source IN (
        'VENDOR_DEFAULT',
        'VENDOR'
    ) 
);


*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_item_det_selection_v (rec_id, stg_rec_id, whse_item_id, record_id, master_item_id, upc_prefix, upc_commodity, upc_mfg, upc_case, upc_item, upc_unit, master_upc, item_description_case, pack, unit_factor, reclaim_item, mcase, item_size, item_size_uom, item_type, case_upc_xref, nielsen_child_group, nielsen_child_group_descr, cs_nielsen_num, cs_nielsen_descr, cs_item_cat, cs_item_cat_description, gl_num, gl_description, ap_vendor_num, ap_vendor_name, reclaim_vendor, reclaim_vendor_name, disposition, brand_name, nos_flag, priv_lab_flag, priv_lab_type, priv_lab_subtype, haz_flag, recall_flag, recall_classification, reclaim_item_status, swell_flag, debit_authorized, vndr_deduct_reason, last_purchase_date, last_sold_date, last_scan_date, avg_num_scans_week, im_tobacco_credit_method, credit_authorized, cs_whse_item_code, cs_whse_org_num, cs_whse_org_name, ssic, whse_pack, item_inv_status, item_purchase_status, cs_whse_inac_date, military_unique, rcost, icost, unit_cost, whse_ap_vendor_num, whse_ap_vendor_name, bv_num, bv_name, bv_subnum, bv_subname, ap_vendor_number, whse_rec_vendor, whse_rec_vendor_name, wh_debit_authorized, wh_vndr_deduct_reason, tobacco_credit_method, whse_disposition, whse_last_update_dt, memo, creation_date, created_by, last_update_date, last_updated_by, debit_reason_desc, wh_debit_reason_desc, lock_upc_comm_flag) AS SELECT  /*ALL_ROWS INDEX(XXRCM_ITEM_MASTER_N03, xim)*/
    row_number() OVER () AS rec_id,
    xim.stg_rec_id,
    xwi.whse_item_id,
    xbc.record_id,
    xim.master_item_id,
    xim.upc_prefix,
    xim.upc_commodity,
    xim.upc_mfg,
    xim.upc_case,
    xim.upc_item,
    xim.upc_unit,
    xim.master_upc,
    xim.item_description_case,
    xim.pack,
    xim.unit_factor,
    xim.reclaim_item,
    xwi.mcase,
    xwi.item_size,
    xwi.item_size_uom,
    xim.item_type,
    xim.case_upc_xref,
    xim.nielsen_child_group,
    xnc.nielsen_child_group_descr,
    xim.cs_nielsen_num,
    xim.cs_nielsen_descr,
    xwi.cs_item_cat,
    xwi.cs_item_cat_description,
    xwi.gl_num,
    xwi.gl_description,
    xim.ap_vendor_num,
    xim.ap_vendor_name,
    xim.reclaim_vendor,
    xim.reclaim_vendor_name,
    xim.disposition,
    xim.brand_name,
    xwi.nos_flag,
    xim.priv_lab_flag,
    xim.priv_lab_type,
    xim.priv_lab_subtype,
    xim.haz_flag,
    xim.recall_flag,
    xim.recall_classification,
    xim.reclaim_item_status,
    xim.swell_flag,
    xim.debit_authorized,
    xim.vndr_deduct_reason,
    xim.last_purchase_date,
    xim.last_sold_date,
    xim.last_scan_date,
    xim.avg_num_scans_week,
    xim.tobacco_credit_method   im_tobacco_credit_method,
	xim.credit_authorized,
    xwi.cs_whse_item_code,
    xwi.cs_whse_org_num,
    xwi.cs_whse_org_name,
    xwi.ssic,
    xwi.pack                    whse_pack,
    xwi.item_inv_status,
    xwi.item_purchase_status,
    xwi.cs_whse_inac_date,
    xwi.military_unique,
    xwi.rcost,
    xwi.icost,
    xwi.unit_cost,
    xwi.ap_vendor_num           whse_ap_vendor_num,
    xwi.ap_vendor_name          whse_ap_vendor_name,
    xwi.bv_num,
    xwi.bv_name,
    xwi.bv_subnum,
    xwi.bv_subname,
    (
      SELECT /*INDEX(XXINV_MF_VENDOR_MASTER_09, a)*/
        vndx_expanded_ap_vendor
        FROM
        rcm_data.xxrcm_mf_vendor_master a
       WHERE
        vndx_vendor_number = xwi.bv_subnum
    ) ap_vendor_number,
    xwi.reclaim_vendor          whse_rec_vendor,
    xwi.reclaim_vendor_name     whse_rec_vendor_name,
    xwi.wh_debit_authorized,
    xwi.wh_vndr_deduct_reason,
    xwi.tobacco_credit_method,
    xwi.disposition             whse_disposition,
    xwi.last_update_date        whse_last_update_dt,
    xbc.memo,
    xbc.creation_date,
    xbc.created_by,
    xbc.last_update_date,
    xbc.last_updated_by,
    (select drc.debit_reason_descr
	from rcm_app.xxrcm_debit_reason_codes_v drc
	where drc.debit_reason= xim.vndr_deduct_reason
	) debit_reason_desc,
	(select drc.debit_reason_descr
	from rcm_app.xxrcm_debit_reason_codes_v drc
	where drc.debit_reason= xwi.wh_vndr_deduct_reason
	) wh_debit_reason_desc,
	xim.lock_upc_comm_flag
  FROM rcm_data.xxrcm_item_master xim
LEFT OUTER JOIN rcm_data.xxrcm_whse_item_details xwi ON (xim.master_item_id = xwi.master_item_id)
LEFT OUTER JOIN rcm_data.xxrcm_bus_comments xbc ON (xim.master_item_id = xbc.master_item_id)
LEFT OUTER JOIN rcm_app.xxrcm_nielsen_child_group_vw xnc ON (xim.nielsen_child_group = xnc.nielsen_child_group_code AND xim.cs_nielsen_num = xnc.cs_nielsen_num AND 'XXRCM_NIELSEN_CHILD_GROUP' = xnc.map_code)
WHERE 1 = 1   --AND xwi.master_item_id      = xbc.master_item_id
    --AND xwi.cs_whse_item_code IS NOT NULL
    --AND xim.reclaim_item        = 'Yes'
;

*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_cust_item_details_ui_v (cust_rec_id, master_item_id, master_upc, customer_name, customer_item, customer_item_descr, customer_department, customer_item_type, customer_item_size, customer_cost, customer_retail, cust_reclaim_item_status, cust_reclaim_item_end_date, customer_upc, customer_whse, chain_num, crosscode_org, crosscode_cs_item, crosscode_ssic, creation_date, created_by, last_update_date, last_updated_by, stg_rec_id, customer_vendor_name, debit_authorized, credit_authorized, recall_flag, disposition, swell_flag, vndr_deduct_reason, recall_classification, cust_rclm_auth, cust_rclm_auth_date, upc, customer_vendor, rule_process_status, customer_code, request_id, cust_upc_item, cust_upc_mfg, locked_cost, cust_debit_reason_desc) AS select xcid.CUST_REC_ID,xcid.MASTER_ITEM_ID,xcid.MASTER_UPC,xcid.CUSTOMER_NAME,xcid.CUSTOMER_ITEM,xcid.CUSTOMER_ITEM_DESCR,xcid.CUSTOMER_DEPARTMENT,xcid.CUSTOMER_ITEM_TYPE,xcid.CUSTOMER_ITEM_SIZE,xcid.CUSTOMER_COST,xcid.CUSTOMER_RETAIL,xcid.CUST_RECLAIM_ITEM_STATUS,xcid.CUST_RECLAIM_ITEM_END_DATE,xcid.CUSTOMER_UPC,xcid.CUSTOMER_WHSE,xcid.CHAIN_NUM,xcid.CROSSCODE_ORG,xcid.CROSSCODE_CS_ITEM,xcid.CROSSCODE_SSIC,xcid.CREATION_DATE,xcid.CREATED_BY,xcid.LAST_UPDATE_DATE,xcid.LAST_UPDATED_BY,xcid.STG_REC_ID,xcid.CUSTOMER_VENDOR_NAME,xcid.DEBIT_AUTHORIZED,xcid.CREDIT_AUTHORIZED,xcid.RECALL_FLAG,xcid.DISPOSITION,xcid.SWELL_FLAG,xcid.VNDR_DEDUCT_REASON,xcid.RECALL_CLASSIFICATION,xcid.CUST_RCLM_AUTH,xcid.CUST_RCLM_AUTH_DATE,xcid.UPC,xcid.CUSTOMER_VENDOR,xcid.RULE_PROCESS_STATUS,xcid.CUSTOMER_CODE,xcid.REQUEST_ID,xcid.CUST_UPC_ITEM,xcid.CUST_UPC_MFG,xcid.LOCKED_COST,(select drc.debit_reason_descr
	 FROM rcm_app.xxrcm_debit_reason_codes_v drc
	where drc.debit_reason= xcid.vndr_deduct_reason
	) cust_debit_reason_desc from rcm_data.xxrcm_cust_item_details xcid;

*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_costing_methods_lkp_vw (cost_seq_id, costing_method, costing_method_name, creation_date, created_by, last_update_date, last_updated_by) AS (
  SELECT vm.n_value1 cost_seq_id
        ,vm.c_value2 costing_method
		,vm.c_value1 costing_method_name
		,vm.creation_date
		,vm.created_by
		,vm.last_update_date
		,vm.last_updated_by
    FROM rcm_cmn.xxrcm_value_map_def vmd
        ,rcm_cmn.xxrcm_value_map vm
   WHERE vmd.map_code = 'VENDOR_COSTING_METHOD'
     AND vm.map_definition_id = vmd.map_definition_id
	 AND statement_timestamp() BETWEEN coalesce( vmd.active_begin_date, statement_timestamp() )
	                 AND coalesce( vmd.active_end_date, statement_timestamp() + interval '1 days' )
	 AND statement_timestamp() BETWEEN coalesce( vm.active_begin_date, statement_timestamp() )
	                 AND coalesce( vm.active_end_date, statement_timestamp() + interval '1 days' )
);


*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_conditional_validation_v (map_definition_id, map_code, map_desc, condition_name, condition_short_name, condition_id, active_date_flag, active_begin_date, active_end_date) AS (select def.map_definition_id,
       def.map_code,
       def.map_desc,
       val.c_value1 CONDITION_NAME,
       val.c_value2 CONDITION_SHORT_NAME,
       val.n_value1 CONDITION_ID,
       def.active_date_flag,
       def.active_begin_date,
       def.active_end_date
FROM rcm_cmn.xxrcm_value_map_def def,
      rcm_cmn.xxrcm_value_map val
where def.map_code = 'CONDITIONAL_VALIDATIONS'
and def.map_definition_id = val.map_definition_id
and statement_timestamp() between def.active_begin_date  and coalesce(def.active_end_date ,statement_timestamp() + interval '1 days') );


*****DONE*****
CREATE OR REPLACE VIEW rcm_app.xxrcm_whse_item_details_ui_v (whse_item_id, master_upc, cs_whse_item_code, cs_whse_org_num, cs_whse_org_name, ssic, item_inv_status, item_purchase_status, cs_whse_inac_date, military_unique, mcase, item_size, item_size_uom, cs_item_cat, cs_item_cat_description, gl_num, gl_description, nos_flag, rcost, icost, acost, unit_cost, retail_cost, freight_cost, ap_vendor_num, ap_vendor_name, bv_num, bv_name, bv_subnum, bv_subname, reclaim_vendor, whse_item_reclaim_flag, creation_date, created_by, last_update_date, last_updated_by, inventory_item_id, organization_id, disposition, disposition_entry, tobacco_credit_method, item_conv_created_by, item_conv_creation_date, item_conv_last_update_date, item_conv_last_updated_by, master_item_id, pack, wh_debit_authorized, wh_vndr_deduct_reason, reclaim_vendor_name, old_item_code, shipper_flag, mod_80k_flag, request_id, rule_process_status, inner_pack, wh_debit_reason_desc, x3pl_flag, upc_case) AS SELECT
    xwid.WHSE_ITEM_ID,
    xwid.MASTER_UPC,
    xwid.CS_WHSE_ITEM_CODE,
    xwid.CS_WHSE_ORG_NUM,
    xwid.CS_WHSE_ORG_NAME,
    xwid.SSIC,
    xwid.ITEM_INV_STATUS,
    xwid.ITEM_PURCHASE_STATUS,
    xwid.CS_WHSE_INAC_DATE,
    xwid.MILITARY_UNIQUE,
    xwid.MCASE,
    xwid.ITEM_SIZE,
    xwid.ITEM_SIZE_UOM,
    xwid.CS_ITEM_CAT,
    xwid.CS_ITEM_CAT_DESCRIPTION,
    xwid.GL_NUM,
    xwid.GL_DESCRIPTION,
    xwid.NOS_FLAG,
    xwid.RCOST,
    xwid.ICOST,
    xwid.ACOST,
    xwid.UNIT_COST,
    xwid.RETAIL_COST,
    xwid.FREIGHT_COST,
    xwid.AP_VENDOR_NUM,
    xwid.AP_VENDOR_NAME,
    xwid.BV_NUM,
    xwid.BV_NAME,
    xwid.BV_SUBNUM,
    xwid.BV_SUBNAME,
    xwid.RECLAIM_VENDOR,
    xwid.WHSE_ITEM_RECLAIM_FLAG,
    xwid.CREATION_DATE,
    xwid.CREATED_BY,
    xwid.LAST_UPDATE_DATE,
    xwid.LAST_UPDATED_BY,
    xwid.INVENTORY_ITEM_ID,
    xwid.ORGANIZATION_ID,
    xwid.DISPOSITION,
    xwid.DISPOSITION_ENTRY,
    xwid.TOBACCO_CREDIT_METHOD,
    xwid.ITEM_CONV_CREATED_BY,
    xwid.ITEM_CONV_CREATION_DATE,
    xwid.ITEM_CONV_LAST_UPDATE_DATE,
    xwid.ITEM_CONV_LAST_UPDATED_BY,
    xwid.MASTER_ITEM_ID,
    xwid.PACK,
    xwid.WH_DEBIT_AUTHORIZED,
    xwid.WH_VNDR_DEDUCT_REASON,
    xwid.RECLAIM_VENDOR_NAME,
    xwid.OLD_ITEM_CODE,
    xwid.SHIPPER_FLAG,
    xwid.MOD_80K_FLAG,
    xwid.REQUEST_ID,
    xwid.RULE_PROCESS_STATUS,
    xwid.INNER_PACK,
    (
        SELECT
            drc.debit_reason_descr
        FROM
            rcm_app.xxrcm_debit_reason_codes_v drc
        WHERE
            drc.debit_reason = xwid.wh_vndr_deduct_reason
    ) wh_debit_reason_desc,
    xwid.X3PL_FLAG,
    xwid.UPC_CASE
FROM
    rcm_app.xxrcm_whse_item_details xwid;
